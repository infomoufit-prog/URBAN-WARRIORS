import { featureIcon, icon } from './ui/icons.js';

const PROFILE_STORIES=[
  {id:'club',icon:'club',label:'CLUB',title:'Gestiona y proyecta tu comunidad',description:'Organiza socios, grupos, sesiones, asistencia, cuotas y comunicaciones mientras refuerzas la presencia pública del club.',example:'Del tatami a la comunidad, sin perder el control de la operativa.'},
  {id:'federacion',icon:'federation',label:'FEDERACIÓN',title:'Conecta tu estructura deportiva',description:'Gestiona federados, licencias, clubes relacionados, calendario y actividad institucional con permisos claramente separados.',example:'Una visión común sin acceder a los datos privados de cada club.'},
  {id:'competidor',icon:'fighter',label:'COMPETIDOR',title:'Construye una trayectoria reconocible',description:'Reúne identidad deportiva, disciplinas, club, Events, Fight Cards y evolución dentro de un perfil propio.',example:'Tu recorrido deportivo deja de estar disperso y empieza a contar una historia.'},
  {id:'profesional',icon:'professional',label:'PROFESIONAL',title:'Haz visible tu actividad',description:'Presenta servicios y gestiona clientes, agenda, credenciales y relaciones según tu especialidad y capacidades.',example:'Entrenadores, managers, sanitarios, árbitros y promotores con un espacio profesional.'},
  {id:'marca',icon:'brand',label:'MARCA',title:'Acércate al público adecuado',description:'Muestra productos, servicios y proyectos ante una audiencia vinculada de forma real al sector.',example:'Presencia corporativa, Showcase y conversaciones con contexto.'},
  {id:'media',icon:'sparkles',label:'MEDIA / CREADOR',title:'Publica como medio o creador',description:'Perfil verificado para canales, medios y creadores de contenido de deportes de contacto, con Social y Showcase.',example:'Una identidad editorial separada de Promotora y de la gestión de clubes.'},
  {id:'espectador',icon:'spectator',label:'ESPECTADOR',title:'Vive el sector desde dentro',description:'Descubre perfiles, publicaciones, eventos y contenido relevante, y guarda tus intereses de forma privada.',example:'Una identidad ligera para seguir lo que de verdad te interesa.'}
];

const ACTION_STORIES=[
  {id:'manage',icon:'club',label:'GESTIONA',product:'GESTIÓN KOMBAX',title:'La base privada de tu actividad.',description:'Centraliza la actividad de clubes, federaciones y profesionales en entornos adaptados a cada responsabilidad.',example:'Asistencia, cuotas, licencias, agenda y comunicaciones.'},
  {id:'connect',icon:'network',label:'CONECTA',product:'KOMBAX SOCIAL',title:'Una red con contexto deportivo.',description:'Construye identidad, comparte actualidad y crea relaciones entre las personas y organizaciones que forman el sector.',example:'Perfiles, publicaciones, comunidad, Mi red y mensajes.'},
  {id:'promote',icon:'shoppingBag',label:'PROMOCIONA',product:'KOMBAX SHOWCASE',title:'Visibilidad donde realmente importa.',description:'Presenta productos, servicios, proyectos y oportunidades ante una audiencia especializada y con intereses afines.',example:'Fichas visuales, guardados, consultas y enlaces profesionales.'},
  {id:'events',icon:'calendar',label:'ORGANIZA Y PARTICIPA',product:'KOMBAX EVENTS',title:'De la expectación a la historia.',description:'Conecta organizadores, participantes, clubes, federaciones, marcas y público alrededor de competiciones y formaciones.',example:'Inscripciones, Fight Cards, resultados, contenidos y álbum oficial.'}
];

const profileCard=profile=>`<article class="kx-explainer-profile" data-kx-profile="${profile.id}">
  <div class="kx-explainer-profile-icon" aria-hidden="true">${featureIcon(profile.icon,{size:46})}</div>
  <div><span>${profile.label}</span><h4>${profile.title}</h4><p>${profile.description}</p><small>${profile.example}</small></div>
</article>`;

const actionCard=action=>`<article class="kx-explainer-action" data-kx-action="${action.id}">
  <div class="kx-explainer-action-icon" aria-hidden="true">${icon(action.icon,{size:28})}</div>
  <div class="kx-explainer-action-meta"><span>${action.label}</span><b>${action.product}</b></div><h4>${action.title}</h4><p>${action.description}</p><small>${action.example}</small>
</article>`;

const teaser=()=>`<section class="kx-discovery" data-kx-product-overview aria-labelledby="kx-discovery-title">
  <div class="kx-discovery-glow" aria-hidden="true"></div>
  <div class="kx-discovery-copy">
    <span class="kx-discovery-kicker">DESCUBRE KOMBAX</span>
    <h2 id="kx-discovery-title">¿Qué es KOMBAX y cómo puede impulsar tu actividad?</h2>
    <p>Mucho más que una herramienta de gestión: el ecosistema donde el sector puede organizar su actividad, construir una identidad reconocible y conectar con nuevas personas, proyectos y oportunidades.</p>
    <button class="kx-discovery-cta" type="button" data-kx-explainer-open>
      <span><b>Descubrir todo lo que puedo hacer</b><small>Perfiles, funciones, ejemplos y beneficios · lectura voluntaria</small></span>
      ${icon('arrowUpRight',{size:21})}
    </button>
  </div>
  <div class="kx-discovery-signals" aria-label="Áreas principales de KOMBAX">
    <div><strong>6</strong><span>perfiles con una función propia</span></div>
    <div><strong>4</strong><span>áreas que trabajan conectadas</span></div>
    <div class="kx-discovery-areas"><span>GESTIÓN</span><span>SOCIAL</span><span>SHOWCASE</span><span>EVENTS</span></div>
  </div>
</section>`;

const heroDiscoveryLink=()=>`<button class="kx-hero-discover" type="button" data-kx-explainer-open>
  <span><strong>¿Primera vez en KOMBAX?</strong><small>Descubre perfiles, funciones, ejemplos y beneficios.</small></span>
  <b>Conocer KOMBAX ${icon('arrowUpRight',{size:16})}</b>
</button>`;

const explainer=()=>`<dialog class="kx-explainer-dialog" data-kx-explainer aria-labelledby="kx-explainer-title" aria-describedby="kx-explainer-lead">
  <div class="kx-explainer-shell">
    <header class="kx-explainer-topbar">
      <div class="kx-explainer-brand"><span>${featureIcon('identity',{size:30})}</span><div><strong>KOMBAX</strong><small>ECOSISTEMA PROFESIONAL</small></div></div>
      <button class="kx-explainer-close" type="button" data-kx-explainer-close aria-label="Cerrar información de KOMBAX">${icon('close',{size:20})}</button>
    </header>
    <div class="kx-explainer-scroll">
      <section class="kx-explainer-hero">
        <div class="kx-explainer-hero-orbit" aria-hidden="true"><i></i><i></i><i></i></div>
        <span>KOMBAX EN 60 SEGUNDOS</span>
        <h2 id="kx-explainer-title">El futuro del sector empieza conectado.</h2>
        <p id="kx-explainer-lead">Un espacio creado específicamente para los deportes de contacto y las artes marciales, donde cada identidad conserva sus funciones, datos y permisos.</p>
        <div class="kx-explainer-principles"><b>Especializado por diseño</b><i></i><b>Abierto a todo el ecosistema</b></div>
      </section>

      <div class="kx-explainer-accordion">
        <details class="kx-explainer-section" open>
          <summary><span><small>01</small><strong>¿Qué es KOMBAX?</strong></span><i aria-hidden="true">${icon('plus',{size:19})}</i></summary>
          <div class="kx-explainer-section-body kx-explainer-definition">
            <div><p>KOMBAX es un ecosistema profesional que une <strong>gestión, identidad, comunidad, promoción y eventos</strong> para los deportes de contacto y las artes marciales.</p><p>Clubes, federaciones, competidores, profesionales, marcas y aficionados pueden avanzar dentro del mismo entorno sin mezclar la información privada de cada organización.</p></div>
            <aside><span>UNA IDEA SENCILLA</span><strong>Organizar la actividad de hoy y construir las oportunidades de mañana.</strong></aside>
          </div>
        </details>

        <details class="kx-explainer-section">
          <summary><span><small>02</small><strong>Encuentra tu lugar</strong></span><i aria-hidden="true">${icon('plus',{size:19})}</i></summary>
          <div class="kx-explainer-section-body"><div class="kx-explainer-profile-grid">${PROFILE_STORIES.map(profileCard).join('')}</div></div>
        </details>

        <details class="kx-explainer-section">
          <summary><span><small>03</small><strong>¿Qué puedo hacer?</strong></span><i aria-hidden="true">${icon('plus',{size:19})}</i></summary>
          <div class="kx-explainer-section-body">
            <div class="kx-ecosystem-intro">
              <span>UN ECOSISTEMA ÚNICO Y DIFERENCIADO</span>
              <h3>Una identidad. Tres experiencias conectadas. Una base de gestión.</h3>
              <p>Social, Showcase y Events no son espacios aislados. Comparten la identidad KOMBAX para que lo que haces, lo que muestras y lo que vives pueda formar parte de una historia profesional coherente.</p>
            </div>
            <div class="kx-explainer-action-grid">${ACTION_STORIES.map(actionCard).join('')}</div>
            <div class="kx-ecosystem-flow" aria-label="Cómo se conecta el ecosistema KOMBAX">
              <div><span>01</span><strong>GESTIÓN</strong><small>Organiza tu actividad</small></div><i>${icon('chevronRight',{size:17})}</i>
              <div><span>02</span><strong>SOCIAL</strong><small>Construye comunidad</small></div><i>${icon('chevronRight',{size:17})}</i>
              <div><span>03</span><strong>SHOWCASE</strong><small>Activa visibilidad</small></div><i>${icon('chevronRight',{size:17})}</i>
              <div><span>04</span><strong>EVENTS</strong><small>Convierte actividad en experiencia</small></div>
            </div>
            <p class="kx-ecosystem-note"><strong>Cada área mantiene su propósito.</strong> La diferencia está en que todas reconocen quién eres dentro de KOMBAX: un perfil puede compartir su recorrido en Social, presentar un servicio en Showcase y participar u organizar una experiencia en Events sin perder su identidad.</p>
            <div class="kx-benefit-intro kx-benefit-inline"><span>LO QUE CONSIGUES</span><h3>Más orden, identidad y oportunidades dentro del mismo ecosistema.</h3><p>Un club convierte su actividad diaria en comunidad y presencia; un competidor construye una trayectoria reconocible; profesionales y marcas acercan sus servicios a una audiencia relevante; y una federación fortalece la conexión con su estructura deportiva.</p></div>
          </div>
        </details>

      </div>

      <section class="kx-explainer-closing">
        <span>CONNECT · COMPETE · GROW</span>
        <h3>Tu actividad ya forma parte del sector.<br>Haz que también forme parte de su futuro.</h3>
      </section>
    </div>
    <footer class="kx-explainer-footer">
      <button class="kx-explainer-route primary" type="button" data-kx-target="gateway-club"><span>${featureIcon('club',{size:28})}</span><b>Gestiono un club</b>${icon('chevronRight',{size:18})}</button>
      <button class="kx-explainer-route" type="button" data-kx-target="gateway-direct"><span>${featureIcon('identity',{size:28})}</span><b>Soy deportista, profesional o marca</b>${icon('chevronRight',{size:18})}</button>
    </footer>
  </div>
</dialog>`;

function closeExplainer(dialog){
  if(dialog?.open&&typeof dialog.close==='function')dialog.close();
  else dialog?.removeAttribute('open');
}

function bindOverview(gateway){
  const dialog=gateway.querySelector('[data-kx-explainer]');
  const openers=[...gateway.querySelectorAll('[data-kx-explainer-open]')];
  let lastOpener=openers[0]||null;
  openers.forEach(opener=>opener.addEventListener('click',()=>{
    lastOpener=opener;
    if(typeof dialog?.showModal==='function')dialog.showModal();
    else dialog?.setAttribute('open','');
  }));
  dialog?.querySelector('[data-kx-explainer-close]')?.addEventListener('click',()=>closeExplainer(dialog));
  dialog?.addEventListener('click',event=>{if(event.target===dialog)closeExplainer(dialog);});
  dialog?.addEventListener('close',()=>lastOpener?.focus({preventScroll:true}));
  dialog?.querySelectorAll('.kx-explainer-section').forEach(section=>section.addEventListener('toggle',()=>{
    if(!section.open)return;
    dialog.querySelectorAll('.kx-explainer-section').forEach(other=>{if(other!==section)other.open=false;});
  }));
  gateway.querySelectorAll('[data-kx-target]').forEach(button=>button.addEventListener('click',()=>{
    const target=document.getElementById(button.dataset.kxTarget);
    if(!target)return;
    closeExplainer(dialog);
    requestAnimationFrame(()=>target.click());
  }));
}

function mountOverview(){
  const gateway=document.querySelector('[data-kombax-view="gateway"]');
  if(!gateway||gateway.querySelector('[data-kx-product-overview]'))return;
  const hero=gateway.querySelector('.gateway-hero');
  if(!hero)return;
  hero.querySelector('.gateway-paths')?.insertAdjacentHTML('beforeend',heroDiscoveryLink());
  hero.insertAdjacentHTML('afterend',`${teaser()}${explainer()}`);
  bindOverview(gateway);
}

const observer=new MutationObserver(mountOverview);
observer.observe(document.documentElement,{childList:true,subtree:true});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mountOverview,{once:true});
else mountOverview();
