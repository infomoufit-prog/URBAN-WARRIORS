import { repos } from '../core/repositories.js';
import { esc, humanError } from '../core/utils.js';
import { openDetail, openForm, toast, closeModal } from '../ui/components.js';
import { icon } from '../ui/icons.js';

const POLICY_FIELDS=[
  ['publish_general','Datos generales'],['publish_schedule','Fecha y horario'],['publish_location','Ubicación'],['publish_visuals','Cartel / banner'],
  ['publish_organizers','Organizadores'],['publish_categories','Categorías'],['publish_participants','Peleadores / participantes'],['publish_fight_card','Fight Card'],
  ['publish_official_weigh_in','Pesaje oficial'],['publish_results','Resultados'],['publish_album','Álbum'],['publish_highlights','Highlights']
];

const statusLabel=s=>({connected:'Conectado',paused:'Conexión pausada',disconnected:'Desconectado'})[s]||s||'No conectado';

function privacyNotice(){return `<section class="kx-event-connection-privacy">${icon('shieldCheck',{size:22})}<div><strong>Conectar no significa compartir</strong><p>Los datos privados de preparación y el histórico de peso nunca se copian a KOMBAX Events. Solo se publica lo que la organización active de forma explícita.</p></div></section>`;}

async function choosePublicEvent(internalEvent,onDone){
  const rows=await repos.kombaxEvents.list({query:internalEvent.nombre||'',limit:30}).catch(()=>[]);
  const body=`${privacyNotice()}<div class="kx-event-connect-list">${rows.length?rows.map(e=>`<button type="button" class="kx-event-connect-candidate" data-kx-connect-public="${esc(e.id)}"><div><strong>${esc(e.nombre||'KOMBAX Evento')}</strong><small>${esc([e.fecha_inicio?new Date(e.fecha_inicio).toLocaleDateString('es-ES'):'',e.municipio,e.organizador_nombre].filter(Boolean).join(' · '))}</small></div><span>Conectar</span></button>`).join(''):`<div class="empty-card compact"><strong>No hay coincidencias públicas.</strong><p>Crea o publica primero el evento en KOMBAX Events y vuelve aquí para conectarlo.</p></div>`}</div>`;
  const {wrap}=openDetail({title:'Conectar con KOMBAX Events',subtitle:internalEvent.nombre||'Evento de Mi Club',body,width:'820px'});
  wrap.querySelectorAll('[data-kx-connect-public]').forEach(b=>b.addEventListener('click',async()=>{b.disabled=true;try{await repos.eventConnections.mutate('connect',{internal_event_id:internalEvent.id,public_event_id:b.dataset.kxConnectPublic});toast('Eventos conectados. Nada se ha publicado automáticamente.');closeModal();await onDone?.();}catch(error){b.disabled=false;toast(humanError(error)||error?.message||'No se pudo conectar. Comprueba que gestionas ambos eventos.','error');}}));
}

function policyFields(policy={}){return POLICY_FIELDS.map(([name,label])=>({name,label,type:'checkbox',value:policy?.[name]===true,full:true}));}

async function editPolicy(connection,onDone){
  openForm({title:'Qué puede publicarse',subtitle:'Todos los bloques son opt-in. El peso privado nunca forma parte de esta configuración.',width:'760px',fields:policyFields(connection.policy||{}),submitText:'Guardar política',onSubmit:async values=>{const policy={};for(const [name] of POLICY_FIELDS)policy[name]=values[name]===true;await repos.eventConnections.mutate('policy.set',{connection_id:connection.id,policy});toast('Política de publicación actualizada');await repos.eventConnections.mutate('projection.publish',{connection_id:connection.id});toast('Vista pública autorizada actualizada');await onDone?.();}});
}

export async function openEventConnectionManager(internalEvent,{onDone=null}={}){
  let connection=null;try{connection=await repos.eventConnections.get({internal_event_id:internalEvent.id});}catch(error){toast(humanError(error)||'No se pudo consultar la conexión.','error');return;}
  if(!connection){await choosePublicEvent(internalEvent,async()=>openEventConnectionManager(internalEvent,{onDone}));return;}
  const enabled=POLICY_FIELDS.filter(([name])=>connection.policy?.[name]===true).map(([,label])=>label);
  const body=`<div class="kx-event-connection-manager">${privacyNotice()}<section class="kx-event-connection-card"><header><div><span>KOMBAX EVENTS</span><h3>${esc(connection.public_event?.nombre||'Evento conectado')}</h3><small>${esc(statusLabel(connection.status))}</small></div><b class="kx-connection-state ${esc(connection.status)}">${esc(statusLabel(connection.status))}</b></header><div class="kx-connection-link"><span>Mi Club</span><b>${esc(connection.internal_event?.nombre||internalEvent.nombre)}</b><i>↔</i><span>KOMBAX Events</span><b>${esc(connection.public_event?.nombre||'Evento público')}</b></div></section><section class="kx-event-publication-summary"><h4>Información autorizada para publicación</h4>${enabled.length?`<div class="kx-policy-pills">${enabled.map(x=>`<span>${esc(x)}</span>`).join('')}</div>`:'<p>Ningún bloque está autorizado todavía. La conexión existe, pero no comparte información.</p>'}</section><div class="row-actions"><button class="btn btn-primary" id="kx-policy-edit">Configurar publicación</button>${connection.status==='connected'?'<button class="btn btn-ghost" id="kx-connection-pause">Pausar conexión</button>':'<button class="btn btn-ghost" id="kx-connection-resume">Reactivar conexión</button>'}<button class="btn btn-ghost" id="kx-connection-disconnect">Desconectar</button></div></div>`;
  const {wrap}=openDetail({title:'Conexión del evento',subtitle:'Mi Club ↔ KOMBAX Events',body,width:'880px'});
  const refresh=async()=>{closeModal();await openEventConnectionManager(internalEvent,{onDone});};
  wrap.querySelector('#kx-policy-edit')?.addEventListener('click',()=>editPolicy(connection,refresh));
  wrap.querySelector('#kx-connection-pause')?.addEventListener('click',async()=>{await repos.eventConnections.mutate('status.set',{connection_id:connection.id,status:'paused'});toast('Conexión pausada');await refresh();});
  wrap.querySelector('#kx-connection-resume')?.addEventListener('click',async()=>{await repos.eventConnections.mutate('status.set',{connection_id:connection.id,status:'connected'});toast('Conexión reactivada');await refresh();});
  wrap.querySelector('#kx-connection-disconnect')?.addEventListener('click',async()=>{await repos.eventConnections.mutate('status.set',{connection_id:connection.id,status:'disconnected'});toast('Eventos desconectados; no se ha eliminado ninguno.');await refresh();});
}

export async function eventConnectionBadge(internalEventId){
  try{const c=await repos.eventConnections.get({internal_event_id:internalEventId});return c?{connected:true,status:c.status,label:statusLabel(c.status),public_event:c.public_event}:null;}catch{return null;}
}
