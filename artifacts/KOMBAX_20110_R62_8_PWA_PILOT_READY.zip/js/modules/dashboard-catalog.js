import { repos } from '../core/repositories.js';
import { state } from '../core/state.js';
import { has } from '../core/permissions.js';
import { esc, byName, money, dateFmt, isoDate, humanError } from '../core/utils.js';
import { pageHeader, hero, metric, progress, quickRow, card, table, empty, badge, openForm, confirmDialog, toast, setError, setMainHtml } from '../ui/components.js';
import { icon } from '../ui/icons.js';
import { migrationAssistBanner, openMigrationPreparation } from './customer-operations.js';

const btn=(id,label,cls='btn btn-ghost btn-sm')=>`<button type="button" class="${cls}" data-id="${esc(id)}">${esc(label)}</button>`;
const bind=(selector,fn)=>document.querySelectorAll(selector).forEach(el=>el.addEventListener('click',()=>fn(el.dataset.id,el)));

export async function renderDashboard(){
  setMainHtml('<div class="loading-card">Preparando tu panel…</div>');
  try{
    const role=state.session?.rol;const d=await repos.dashboard.load();const today=isoDate();
    const activeMembers=d.members.filter(x=>x.estado==='activo');const activeGroups=d.groups.filter(x=>x.activo);const pendingFees=d.fees.filter(x=>['pendiente','vencida','parcialmente_pagada'].includes(x.estado));const overdue=d.fees.filter(x=>x.estado==='vencida');
    const pendingAmount=pendingFees.reduce((sum,x)=>sum+Number(x.importe||0),0);const future=d.sessions.filter(x=>String(x.fecha)>=today&&x.estado!=='cancelada').sort((a,b)=>`${a.fecha} ${a.hora_inicio}`.localeCompare(`${b.fecha} ${b.hora_inicio}`));
    const unreadCount=Number(d.notificationSummary?.club_unread_items||0);const pendingPre=d.pre.filter(x=>['enviada','en_revision','pendiente_documentacion','lista_espera'].includes(x.estado));const pendingPayments=d.payments.filter(x=>x.estado_validacion==='pendiente');
    const occupancy=activeGroups.map(g=>{const enrolled=new Set(d.enrollments.filter(e=>e.grupo_id===g.id&&e.activa).map(e=>e.socio_id)).size;const cap=Number(g.plazas||0);return {...g,enrolled,pct:cap?Math.min(100,Math.round(enrolled/cap*100)):0};}).sort((a,b)=>b.pct-a.pct);
    if(role==='economia'){
      const paid=d.payments.filter(x=>x.estado_validacion==='validado').reduce((sum,x)=>sum+Number(x.importe||0),0);
      setMainHtml(`${hero({kicker:'Tesorería',title:'Control financiero, sin ruido.',body:'Cuotas, cobros y validaciones priorizadas para que la caja del club esté siempre al día.',actions:'<button class="btn btn-primary" data-nav="finance">Abrir finanzas</button><button class="btn btn-ghost" data-nav="reminders">Avisos de cobro</button>',sideValue:money(paid),sideLabel:'pagos validados visibles'})}
        <div class="metrics">${metric('Pendiente',money(pendingAmount),`${pendingFees.length} cuotas`)}${metric('Vencido',overdue.length,`${money(overdue.reduce((s,x)=>s+Number(x.importe||0),0))}`)}${metric('Pagos por validar',pendingPayments.length)}${metric('Recibos / pagos',d.payments.length)}</div>
        <div class="grid-2">${card('Prioridad de hoy',`${quickRow(icon('wallet'),'Pagos por validar',`${pendingPayments.length} comunicaciones pendientes`,'<button class="btn btn-primary btn-sm" data-nav="finance">Revisar</button>')}${quickRow(icon('bell'),'Cuotas vencidas',`${overdue.length} cuotas requieren seguimiento`,'<button class="btn btn-ghost btn-sm" data-nav="reminders">Avisos</button>')}`)}${card('Últimos movimientos',d.payments.slice(0,6).map(x=>quickRow(icon('creditCard'),money(x.importe),`${dateFmt(x.fecha)} · ${x.estado_validacion}`,badge(x.estado_validacion,x.estado_validacion==='validado'?'ok':x.estado_validacion==='rechazado'?'danger':'warn'))).join('')||empty('Sin pagos'))}</div>`);
    }else if(role==='monitor'){
      const todaySessions=future.filter(x=>String(x.fecha)===today);const myGroups=activeGroups;
      setMainHtml(`${hero({kicker:'Hoy',title:`Hola, ${state.session?.nombre||'Warrior'}.`,body:'Tus clases, asistencia y seguimiento en un panel pensado para moverte rápido desde el tatami.',actions:'<button class="btn btn-primary" data-nav="attendance">Pasar asistencia</button><button class="btn btn-ghost" data-nav="members">Mis alumnos</button>',sideValue:String(todaySessions.length),sideLabel:'clases programadas hoy',dark:true})}
        <div class="grid-2">${card('Clases de hoy',todaySessions.length?todaySessions.map(s=>quickRow(String(s.hora_inicio||'').slice(0,5),activeGroups.find(g=>g.id===s.grupo_id)?.nombre||'Clase',`${s.monitor_nombre||'Monitor'} · ${s.estado}`,'<button class="btn btn-primary btn-sm" data-nav="attendance">Pasar lista</button>')).join(''):empty('Sin clases hoy'))}${card('Mis grupos',myGroups.length?myGroups.slice(0,8).map(g=>{const o=occupancy.find(x=>x.id===g.id)||{enrolled:0,pct:0};return `<div class="occupancy"><div><strong>${esc(g.nombre)}</strong><small>${esc(g.monitor_nombre||'')}</small></div><span>${o.enrolled}/${g.plazas||'—'}</span>${progress(o.pct)}</div>`}).join(''):empty('Sin grupos asignados'))}</div>`);
    }else if(role==='comunicacion'){
      setMainHtml(`${hero({kicker:'Comunicación',title:'La voz del club, en una sola bandeja.',body:'Publica noticias, eventos y avisos manteniendo una experiencia coherente para familias, alumnado y equipo.',actions:'<button class="btn btn-primary" data-nav="communications">Gestionar publicaciones</button><button class="btn btn-ghost" data-nav="notifications">Ver avisos</button>',sideValue:String(unreadCount),sideLabel:'notificaciones sin leer',dark:true})}
        <div class="metrics">${metric('Avisos sin leer',unreadCount)}${metric('Sesiones próximas',future.length)}${metric('Grupos activos',activeGroups.length)}${metric('Socios activos',activeMembers.length)}</div>`);
    }else{
      const secretary=role==='secretaria';const coordination=role==='coordinacion';const actionItems=[
        {icon:icon('userPlus'),title:'Preinscripciones pendientes',sub:`${pendingPre.length} solicitudes por revisar`,nav:'enrollments',count:pendingPre.length},
        {icon:icon('wallet'),title:'Pagos por validar',sub:`${pendingPayments.length} comunicaciones de pago`,nav:'finance',count:pendingPayments.length},
        {icon:icon('bell'),title:'Cuotas vencidas',sub:`${overdue.length} cuotas requieren seguimiento`,nav:'reminders',count:overdue.length},
        {icon:icon('user'),title:'Alumnos activos',sub:`${activeMembers.length} fichas activas`,nav:'members',count:activeMembers.length}
      ].sort((a,b)=>b.count-a.count);
      setMainHtml(`${hero({kicker:secretary?'Secretaría · Operación diaria':coordination?'Coordinación · Gestión operativa':'Gestor de la app · Panel global',title:secretary?'Todo lo pendiente, bajo control.':coordination?'Coordina el club desde un único panel.':'Todo el gimnasio, en una sola app.',body:secretary?'Prioriza solicitudes, documentación, matrículas, pagos y clases del día.':coordination?'Alumnos, grupos, sesiones, finanzas, publicaciones y documentación con permisos operativos amplios.':'Inscripciones, clases, asistencia, finanzas y comunicaciones con una visión global del club.',actions:'<button class="btn btn-primary" data-nav="members">Gestionar alumnos</button><button class="btn btn-ghost" data-nav="attendance">Pasar asistencia</button>',sideValue:String(activeMembers.length),sideLabel:'socios activos'})}
        <div class="metrics">${metric('Socios activos',activeMembers.length)}${metric('Preinscripciones',pendingPre.length,'pendientes de revisar')}${metric('Ocupación media',`${occupancy.length?Math.round(occupancy.reduce((s,x)=>s+x.pct,0)/occupancy.length):0}%`,`${activeGroups.length} grupos activos`)}${metric('Cuotas vencidas',overdue.length,money(overdue.reduce((s,x)=>s+Number(x.importe||0),0)))}</div>
        <div class="grid-2">${card('Acciones pendientes',actionItems.map(x=>quickRow(x.icon,x.title,x.sub,`<button class="btn ${x.count?'btn-primary':'btn-ghost'} btn-sm" data-nav="${x.nav}">Abrir</button>`)).join(''))}${card('Clases y ocupación',occupancy.length?occupancy.slice(0,7).map(g=>`<div class="occupancy"><div><strong>${esc(g.nombre)}</strong><small>${esc(g.monitor_nombre||'Sin monitor asignado')}</small></div><span>${g.enrolled}/${g.plazas||'—'}</span>${progress(g.pct)}</div>`).join(''):empty('Sin grupos activos'))}</div>
        ${card('Próximas sesiones',future.length?future.slice(0,8).map(x=>quickRow(String(x.fecha).slice(8,10),activeGroups.find(g=>g.id===x.grupo_id)?.nombre||'Clase',`${dateFmt(x.fecha)} · ${String(x.hora_inicio||'').slice(0,5)} · ${x.estado}`,badge(x.estado,x.estado==='completada'?'ok':x.estado==='cancelada'?'danger':'neutral'))).join(''):empty('Sin sesiones próximas'))}`);
    }
    if(!['familia','alumno'].includes(role)){
      const heroNode=document.querySelector('#main-view .hero');
      heroNode?.insertAdjacentHTML('afterend',migrationAssistBanner({title:'¿Vienes de otro programa, Excel o fichas en papel?',body:'KOMBAX Migrations te ayuda a trasladar alumnos, grupos, cuotas y documentación mediante chat directo y subida de archivos, con revisión antes de importar.'}));
      document.querySelector('#main-view [data-kx-migration-assist]')?.addEventListener('click',openMigrationPreparation);
    }
    document.querySelectorAll('#main-view [data-nav]').forEach(b=>b.addEventListener('click',()=>document.querySelector(`.nav-item[data-nav="${b.dataset.nav}"]`)?.click()||document.querySelector(`.bottom-nav [data-nav="${b.dataset.nav}"]`)?.click()));
  }catch(e){setError(e);setMainHtml(`${pageHeader('Inicio')} ${empty('No se pudo cargar el panel',humanError(e))}`)}
}

function disciplineFields(){return [
  {name:'nombre',label:'Nombre',required:true},{name:'orden',label:'Orden',type:'number',value:0},
  {name:'descripcion',label:'Descripción',type:'textarea',full:true},{name:'color',label:'Color',type:'color',value:'#ffffff'},
  {name:'activa',label:'Disciplina activa',type:'checkbox',value:true}
]}
function gradeFields(disciplines){return [
  {name:'disciplina_id',label:'Disciplina',type:'select',required:true,options:disciplines.filter(d=>d.activa).map(d=>({value:d.id,label:d.nombre}))},
  {name:'nombre',label:'Nombre del grado',required:true},{name:'orden',label:'Orden',type:'number',value:1,min:1},{name:'color',label:'Color',type:'color',value:'#ffffff'},
  {name:'meses_minimos',label:'Meses mínimos',type:'number',min:0},{name:'activo',label:'Grado activo',type:'checkbox',value:true}
]}

export async function renderCatalog(){
  setMainHtml('<div class="loading-card">Cargando catálogo…</div>');
  try{
    const [disciplines,grades]=await Promise.all([repos.catalog.disciplines(),repos.catalog.grades()]);disciplines.sort(byName);const canD=has(state.session,'discipline'),canG=has(state.session,'grade');
    const cards=disciplines.map(d=>{const gs=grades.filter(g=>g.disciplina_id===d.id).sort((a,b)=>Number(a.orden||0)-Number(b.orden||0));return `<section class="card"><div class="card-head"><div><div class="page-kicker">Disciplina ${d.activa?'activa':'inactiva'}</div><h2 style="font-size:22px">${esc(d.nombre)}</h2></div><div class="row-actions">${badge(d.activa?'Activa':'Inactiva',d.activa?'ok':'neutral')}${canD?btn(d.id,'Editar','btn btn-ghost btn-sm edit-discipline')+btn(d.id,d.activa?'Desactivar':'Activar','btn btn-ghost btn-sm toggle-discipline')+btn(d.id,'Eliminar','btn btn-danger btn-sm delete-discipline'):''}${canG?`<button class="btn btn-primary btn-sm add-grade" data-id="${esc(d.id)}">+ Grado</button>`:''}</div></div><p class="muted" style="margin:0 0 15px;line-height:1.5">${esc(d.descripcion||'Sin descripción')}</p><div style="display:flex;gap:7px;flex-wrap:wrap">${gs.length?gs.map(g=>`<span class="grade-chip-wrap"><button type="button" class="profile-chip ${g.activo?'':'muted'} ${canG?'edit-grade':''}" data-id="${esc(g.id)}"><span style="width:9px;height:9px;border-radius:50%;background:${esc(g.color||'#fff')}"></span><strong>${esc(g.nombre)}</strong></button>${canG?`<button type="button" class="icon-btn delete-grade" data-id="${esc(g.id)}" title="Eliminar grado">${icon('trash',{size:14})}</button>`:''}</span>`).join(''):'<span class="muted">Sin grados configurados</span>'}</div></section>`}).join('');
    setMainHtml(`${pageHeader('Disciplinas y grados','Estructura deportiva del club',`${canD?'<button class="btn btn-primary" id="new-discipline">Nueva disciplina</button>':''}${canG?'<button class="btn btn-ghost" id="new-grade">Nuevo grado</button>':''}`,'Club')}${cards||empty('Sin disciplinas')}`);
    const reload=()=>renderCatalog();
    document.getElementById('new-discipline')?.addEventListener('click',()=>openForm({title:'Nueva disciplina',fields:disciplineFields(),onSubmit:async v=>{await repos.catalog.saveDiscipline(v);toast('Disciplina guardada');await reload();}}));
    bind('.edit-discipline',(id)=>{const d=disciplines.find(x=>x.id===id);openForm({title:'Editar disciplina',fields:disciplineFields(),initial:d,onSubmit:async v=>{await repos.catalog.saveDiscipline({...d,...v,id});toast('Disciplina actualizada');await reload();}})});
    bind('.toggle-discipline',async(id,el)=>{const d=disciplines.find(x=>x.id===id);el.disabled=true;try{await repos.catalog.saveDiscipline({...d,activa:!d.activa});toast(d.activa?'Disciplina desactivada':'Disciplina activada');await reload();}catch(e){setError(e);el.disabled=false;}});
    bind('.delete-discipline',id=>confirmDialog('Eliminar disciplina','Solo se elimina si nunca se ha utilizado. Si tiene grupos, matrículas, sesiones o graduaciones, desactívala y conserva el histórico.',async()=>{await repos.catalog.deleteDiscipline(id);toast('Disciplina eliminada');await reload();},{confirmText:'Eliminar',danger:true}));
    const openGrade=(g={})=>openForm({title:g.id?'Editar grado':'Nuevo grado',fields:gradeFields(disciplines),initial:g,onSubmit:async v=>{await repos.catalog.saveGrade({...g,...v,id:g.id||null});toast('Grado guardado');await reload();}});
    document.getElementById('new-grade')?.addEventListener('click',()=>openGrade());bind('.edit-grade',id=>openGrade(grades.find(x=>x.id===id)));bind('.add-grade',id=>openGrade({disciplina_id:id,activo:true,orden:grades.filter(g=>g.disciplina_id===id).length+1}));bind('.delete-grade',id=>confirmDialog('Eliminar grado','Solo se elimina si nunca se ha utilizado. Si tiene graduaciones asociadas, desactívalo y conserva el histórico.',async()=>{await repos.catalog.deleteGrade(id);toast('Grado eliminado');await reload();},{confirmText:'Eliminar',danger:true}));
  }catch(e){setError(e);setMainHtml(`${pageHeader('Disciplinas y grados')} ${empty('No se pudo cargar el catálogo',humanError(e))}`)}
}
