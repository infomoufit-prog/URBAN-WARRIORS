import { repos } from '../core/repositories.js';
import { esc, money, dtFmt, humanError } from '../core/utils.js';
import { KOMBAX_BRAND } from '../core/platform.js';
import { pageHeader, empty, openForm, openDetail, confirmDialog, toast, setError, setMainHtml, subviewActions, bindSubviewActions } from '../ui/components.js';
import { icon } from '../ui/icons.js';
import { openKombaxPublicProfile } from './public-profile.js';
import { brandHero } from '../ui/brand-hero.js';
import { mediaFrameAttrs, openMediaFramingEditor } from '../ui/media-framing.js';

const PAGE_SIZE=24;
const CTA_LABELS={info:'Más información',contact:'Contactar',shop:'Ir a tienda',web:'Visitar web',where:'Dónde encontrar'};
const PROVIDER_LABELS={club:'Club',marca:'Marca',media:'Media / Creador',federacion:'Federación',competidor:'Competidor',profesional:'Profesional'};
const LIMIT_LABELS={15:'máximo 15',30:'máximo 30'};
let items=[];
let categories=[];
let managedBrands=[];
let cursor=null;
let done=false;
let currentQuery='';
let currentCategory='';
let activeView='catalog';
let managementLimit=60;

const categoryIcon=slug=>icon(({equipamiento:'dumbbell',protecciones:'shield',textil:'package',nutricion:'activity',tecnologia:'settings',servicios:'users'})[slug]||'sparkles',{size:28});
const safeExternal=url=>/^https:\/\/[^\s]+$/i.test(String(url||''))?String(url):'';
const slugify=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,80);
const ctaLabel=item=>String(item?.cta_label||'').trim()||CTA_LABELS[item?.cta_tipo]||CTA_LABELS.info;
const isProfessionalService=item=>String(item?.listing_kind||'product')==='professional_service';
const isProfessionalProvider=brand=>String(brand?.sujeto_tipo||'')==='profesional';
const stockStatusLabel=status=>({in_stock:'En stock',low_stock:'Stock bajo',out_of_stock:'Sin stock',not_tracked:'Stock no controlado',not_applicable:'Servicio'})[status]||'Stock';
const ORDER_STATUS=Object.freeze({
  received:{label:'Pendiente de pago',tone:'pending',step:0},payment_confirmed:{label:'Pago confirmado',tone:'paid',step:1},preparing:{label:'Preparando',tone:'preparing',step:2},shipped:{label:'Enviado',tone:'shipped',step:3},delivered:{label:'Entregado',tone:'delivered',step:4},cancelled:{label:'Cancelado',tone:'cancelled',step:-1},refunded:{label:'Reembolsado',tone:'refunded',step:-1},incident:{label:'Incidencia abierta',tone:'incident',step:-1}
});
const orderMeta=status=>ORDER_STATUS[String(status||'')]||{label:String(status||'Pendiente'),tone:'pending',step:0};
const orderItemsLabel=o=>(Array.isArray(o?.items)?o.items:[]).map(i=>`${Number(i.quantity||1)}× ${i.name||'Producto'}`).join(' · ')||'Pedido Showcase';
const shippingLine=o=>{const raw=o?.shipping_address||{};const a=raw?.address||raw||{};return [a.line1,a.line2,a.postal_code,a.city,a.state,a.country].filter(Boolean).join(' · ');};
function orderProgress(status){const meta=orderMeta(status);if(meta.step<0)return `<div class="showcase-order-progress is-${esc(meta.tone)}"><span class="active"></span><small>${esc(meta.label)}</small></div>`;const labels=['Pago','Confirmado','Preparando','Enviado','Entregado'];return `<div class="showcase-order-progress">${labels.map((x,i)=>`<span class="${i<=meta.step?'active':''}"><i></i><small>${esc(x)}</small></span>`).join('')}</div>`;}

function statusBadge(ok,label,pending='Pendiente'){return `<span class="kx-market-status ${ok?'ok':'pending'}">${ok?icon('checkCircle',{size:14}):icon('clock',{size:14})} ${esc(ok?label:pending)}</span>`;}
function sellerApplicationEditable(status){return !['verified','suspended'].includes(String(status||''));}

async function openSellerCenter(brand){
  try{
    const [data,connectSnapshot]=await Promise.all([repos.marketplace.sellerCenter(brand.id),repos.payments.connectStatus('showcase_provider',brand.id).catch(()=>null)]),checks=data?.checks||{},base=data?.base_verification||{},app=data?.application||{},policies=Array.isArray(data?.policies)?data.policies:[],stripe=data?.stripe||connectSnapshot||{};
    const step=(title,ok,detail)=>`<article class="kx-seller-step ${ok?'complete':''}"><span>${ok?icon('checkCircle',{size:20}):icon('clock',{size:20})}</span><div><strong>${esc(title)}</strong><small>${esc(detail)}</small></div></article>`;
    const policyHtml=policies.map(p=>`<article class="kx-market-policy ${p.accepted?'accepted':''}"><header><div><strong>${esc(p.title)}</strong><small>Versión ${esc(p.version)} · ${p.legal_review_status==='approved'?'Revisión jurídica aprobada':'Borrador QA · revisión jurídica pendiente'}</small></div>${statusBadge(p.accepted,'Aceptada','Pendiente de aceptar')}</header><details><summary>Leer documento</summary><p>${esc(p.body)}</p></details>${!p.accepted?`<button type="button" class="btn btn-primary btn-sm" data-seller-policy="${esc(p.code)}" data-policy-version="${esc(p.version)}">Aceptar documento</button>`:''}</article>`).join('');
    const body=`<div class="kx-seller-center"><div class="kx-seller-center-status">${step('Identidad KOMBAX',checks.identity_verified,'Verificación de Club/Marca necesaria')}${step('Alta de vendedor',checks.seller_verified,app.status?`Estado: ${app.status}`:'Solicitud pendiente')}${step('Contrato y políticas',checks.policies_accepted,'Aceptar documentos vigentes')}${step('Stripe Connect',checks.stripe_ready,stripe.status?`Estado Stripe: ${stripe.status}`:'Configurar cobros')}${step('Venta habilitada',checks.selling_ready,'Se activa cuando todos los pasos están completos')}</div>
      <div class="alert ${checks.selling_ready?'success':''}"><strong>${checks.selling_ready?'Vendedor activo':'Alta de vendedor incompleta'}</strong><span>${checks.selling_ready?'Puedes activar productos para compra directa en KOMBAX Showcase.':'Completa los pasos pendientes. La compraventa se realiza entre comprador y vendedor y Stripe procesa el pago directamente para la cuenta conectada del vendedor.'}</span></div>
      <section><h4>1. Identidad comercial</h4><div class="kx-market-facts"><span>Proveedor <strong>${esc(data?.provider?.name||brand.nombre)}</strong></span><span>Tipo <strong>${esc(PROVIDER_LABELS[data?.provider?.type]||data?.provider?.type||'Vendedor')}</strong></span><span>Verificación KOMBAX <strong>${checks.identity_verified?'Verificada':'Pendiente'}</strong></span>${base.responsible?`<span>Responsable <strong>${esc(base.responsible)}</strong></span>`:''}</div>${!checks.identity_verified?'<p class="muted">Primero debe completarse la verificación KOMBAX de la entidad. No volveremos a pedir documentación ya validada.</p>':''}</section>
      <section><h4>2. Solicitud de vendedor</h4>${app.id?`<div class="kx-market-facts"><span>Estado <strong>${esc(app.status)}</strong></span><span>Razón social <strong>${esc(app.legal_name||'—')}</strong></span><span>NIF/CIF <strong>${esc(app.tax_id||'—')}</strong></span><span>País <strong>${esc(app.country||'—')}</strong></span></div>${app.review_note?`<div class="alert"><strong>Nota de revisión</strong><span>${esc(app.review_note)}</span></div>`:''}`:'<p class="muted">Confirma los datos de actividad comercial y solicita el alta específica para vender.</p>'}${sellerApplicationEditable(app.status)?'<button type="button" class="btn btn-primary" id="seller-application-edit">Completar / enviar solicitud</button>':''}</section>
      <section><h4>3. Contrato y políticas</h4><div class="kx-market-policy-list">${policyHtml||'<p class="muted">No hay documentos activos.</p>'}</div></section>
      <section><h4>4. Cobros con Stripe</h4><div class="kx-market-facts"><span>Estado <strong>${esc(stripe.status||'No configurado')}</strong></span><span>Cobros <strong>${stripe.charges_enabled?'Activos':'Pendientes'}</strong></span><span>Transferencias <strong>${stripe.payouts_enabled?'Activas':'Pendientes'}</strong></span><span>Modelo <strong>${esc(stripe.charge_model||'Direct charge')}</strong></span></div><p class="muted">Los datos bancarios y de tarjeta se gestionan en Stripe. KOMBAX no almacena tarjeta, CVC ni cuenta bancaria del comprador.</p><button type="button" class="btn btn-ghost" id="seller-stripe-connect">${checks.stripe_ready?'Revisar Stripe Connect':'Configurar Stripe Connect'}</button></section>
    </div>`;
    const modal=openDetail({title:'Centro de vendedor',subtitle:`${brand.nombre} · alta, políticas, cobros y estado de venta`,body,width:'980px',className:'kx-seller-center-modal'});
    modal.wrap.querySelector('#seller-application-edit')?.addEventListener('click',()=>openForm({title:'Alta de vendedor KOMBAX Showcase',subtitle:'Reutilizamos la identidad KOMBAX ya verificada. Confirma únicamente los datos comerciales necesarios para vender.',fields:[
      {name:'legal_name',label:'Razón social / nombre legal',required:true,value:app.legal_name||base.legal_name||brand.nombre},{name:'tax_id',label:'NIF / CIF / VAT',required:true,value:app.tax_id||base.tax_id||''},{name:'country',label:'País (código ISO)',required:true,value:app.country||'ES',maxLength:2},{name:'registered_address',label:'Domicilio legal / administrativo',required:true,full:true,value:app.registered_address||base.registered_address||''},{name:'support_email',label:'Email de atención al comprador',type:'email',required:true,value:app.support_email||base.support_email||''},{name:'support_phone',label:'Teléfono de atención',required:true,value:app.support_phone||base.support_phone||''},{name:'returns_contact',label:'Contacto para devoluciones (opcional)',value:app.returns_contact||''},{name:'seller_shipping',label:'Realiza envíos',type:'checkbox',value:(app.shipping_modes||[]).includes('seller_shipping'),full:true},{name:'seller_pickup',label:'Permite recogida',type:'checkbox',value:(app.shipping_modes||[]).includes('seller_pickup'),full:true},{name:'digital',label:'Entrega digital (si aplica)',type:'checkbox',value:(app.shipping_modes||[]).includes('digital'),full:true},{name:'compliance_statement',label:'Declaro que los productos y mi actividad cumplen la normativa aplicable',type:'checkbox',required:true,value:app.compliance_statement===true,full:true},{name:'marketplace_statement',label:'Declaro que actúo como vendedor independiente y soy responsable del producto, entrega, garantía y devoluciones',type:'checkbox',required:true,value:app.marketplace_statement===true,full:true}],submitText:'Enviar solicitud',onSubmit:async v=>{const shipping_modes=['seller_shipping','seller_pickup','digital'].filter(k=>v[k]===true);await repos.marketplace.sellerApplication(brand.id,'submit',{...v,shipping_modes});toast('Solicitud de vendedor enviada');modal.close();await openSellerCenter(brand);}}));
    modal.wrap.querySelectorAll('[data-seller-policy]').forEach(btn=>btn.addEventListener('click',async()=>{btn.disabled=true;try{await repos.marketplace.acceptSellerPolicy(brand.id,btn.dataset.sellerPolicy,btn.dataset.policyVersion);toast('Documento aceptado');modal.close();await openSellerCenter(brand);}catch(error){btn.disabled=false;setError(error);}}));
    modal.wrap.querySelector('#seller-stripe-connect')?.addEventListener('click',async e=>{e.currentTarget.disabled=true;try{const out=await repos.payments.connectOnboarding('showcase_provider',brand.id);if(!out?.url)throw new Error('No se pudo iniciar Stripe Connect.');location.assign(out.url);}catch(error){e.currentTarget.disabled=false;setError(error);}});
  }catch(error){setError(error);}
}

async function ensureBuyerMarketplaceTerms(){
  const trust=await repos.marketplace.buyerTrust();const missing=(trust?.policies||[]).filter(p=>p.required&&!p.accepted);if(!missing.length)return true;
  return new Promise(resolve=>{
    const body=`<div class="kx-buyer-terms"><div class="alert"><strong>Antes de comprar</strong><span>La compraventa se realiza con el vendedor indicado. Stripe procesa el pago. Lee y acepta las condiciones vigentes de KOMBAX Showcase.</span></div>${missing.map(p=>`<article class="kx-market-policy"><header><strong>${esc(p.title)}</strong><small>Versión ${esc(p.version)} · ${p.legal_review_status==='approved'?'Aprobada':'Borrador QA · revisión jurídica pendiente'}</small></header><p>${esc(p.body)}</p></article>`).join('')}<button type="button" class="btn btn-primary" id="accept-buyer-marketplace-terms">Aceptar y continuar</button></div>`;
    const modal=openDetail({title:'Condiciones de compra en Showcase',subtitle:'Protección del comprador y condiciones de marketplace',body,width:'850px'});
    modal.wrap.querySelector('#accept-buyer-marketplace-terms')?.addEventListener('click',async e=>{e.currentTarget.disabled=true;try{for(const p of missing)await repos.marketplace.acceptBuyerPolicy(p.code,p.version);modal.close();resolve(true);}catch(error){e.currentTarget.disabled=false;setError(error);resolve(false);}});
  });
}

async function openBuyerIdentityVerification(onDone){
  const trust=await repos.marketplace.buyerTrust();const current=trust?.identity_request||{};
  openForm({title:'Verificación de identidad del comprador',subtitle:'Opcional para compras normales. Puede utilizarse para reforzar confianza, resolver riesgos o atender una comprobación específica. El documento queda privado para verificación KOMBAX.',fields:[{name:'full_name',label:'Nombre legal completo',required:true,value:current.full_name||''},{name:'country',label:'País (código ISO)',required:true,value:current.country||'ES',maxLength:2},{name:'reason',label:'Motivo / contexto (opcional)',type:'textarea',maxLength:800,full:true,value:current.reason||''},{name:'document_type',label:'Tipo de documento',type:'select',value:'identity',options:[{value:'identity',label:'Identidad'},{value:'residence',label:'Residencia'},{value:'other',label:'Otro'}]},{name:'document',label:'Documento privado',type:'file',accept:'.pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp',required:current.status!=='needs_information',full:true,help:'PDF/JPG/PNG/WEBP · máximo 15 MB.'}],submitText:'Enviar para revisión',onSubmit:async v=>{const out=await repos.marketplace.buyerIdentitySubmit({full_name:v.full_name,country:v.country,reason:v.reason});const requestId=out?.data?.id||current.id;if(v.document&&requestId)await repos.marketplace.uploadBuyerIdentityDocument(requestId,v.document_type,v.document);toast('Solicitud de identidad enviada');await onDone?.();}});
}

function buyerTrustHtml(trust){const status=trust?.identity_status||'not_requested';return `<section class="kx-buyer-trust"><div><span class="page-kicker">CONFIANZA Y PROTECCIÓN</span><h3>Tu estado como comprador</h3><p>KOMBAX no exige DNI para una compra ordinaria. Stripe valida el pago; la identidad reforzada es opcional salvo que exista una necesidad concreta.</p></div><div class="kx-buyer-trust-badges">${statusBadge(trust?.account_verified===true,'Cuenta KOMBAX','Cuenta pendiente')}${statusBadge(trust?.payment_verified===true,'Pago verificado','Sin pago verificado')}${statusBadge(trust?.identity_verified===true,'Identidad verificada',status==='not_requested'?'Identidad opcional':`Identidad: ${status}`)}</div>${!trust?.identity_verified?'<button type="button" class="btn btn-ghost btn-sm" id="buyer-identity-verify">Solicitar verificación de identidad</button>':''}</section>`;}


function showcaseBrand(){
  return brandHero({area:'showcase',headline:'Muestra. Promociona.',accent:'Destaca.',body:'Escaparate profesional de KOMBAX para presentar perfiles, productos, servicios y oportunidades del mundo del combate.',features:[{icon:'user',label:'Perfiles'},{icon:'package',label:'Productos'},{icon:'professional',label:'Servicios'},{icon:'sparkles',label:'Oportunidades'}]});
}

function controls(){
  return `<div class="showcase-controls"><div class="showcase-search"><input id="showcase-query" type="search" value="${esc(currentQuery)}" placeholder="Buscar perfiles, productos, servicios o categorías"><button class="btn btn-primary" id="showcase-search">Buscar</button></div><div class="showcase-categories"><button type="button" data-showcase-category="" class="${currentCategory?'':'active'}">Todo</button>${categories.map(c=>`<button type="button" data-showcase-category="${esc(c.slug)}" class="${currentCategory===c.slug?'active':''}">${esc(c.nombre)}</button>`).join('')}</div></div>`;
}

function cardHtml(item){
  const image=safeExternal(item.imagen_url),service=isProfessionalService(item);
  return `<article class="showcase-item ${item.destacado?'featured':''} ${service?'is-service':''}" data-showcase-detail="${esc(item.id)}" tabindex="0" role="button" aria-label="Abrir ${esc(item.nombre)}">
    <div class="showcase-item-visual">${image?`<img ${mediaFrameAttrs(item.imagen_presentacion,"product")} src="${esc(image)}" alt="${esc(item.nombre)}" loading="lazy">`:`<div>${categoryIcon(item.categoria_slug)}<span>${esc(item.categoria_nombre||'Showcase')}</span></div>`}${item.etiqueta_destacada?`<b>${esc(item.etiqueta_destacada)}</b>`:''}<button class="showcase-save-icon ${item.guardado?'active':''}" type="button" data-showcase-save="${esc(item.id)}" aria-label="${item.guardado?'Quitar de guardados':'Guardar'}">${icon(item.guardado?'bookmarkCheck':'bookmark',{size:18})}</button></div>
    <div class="showcase-item-body"><span class="page-kicker">${esc(item.marca_nombre)} ${item.marca_verificada?icon('shieldCheck',{size:13}):''}</span><h2>${esc(item.nombre)}</h2><p>${esc(item.resumen||'Información disponible en KOMBAX Showcase.')}</p><footer><span>${service?'Servicio profesional':esc(item.product_type||item.categoria_nombre||'Producto')}</span>${!service&&item.commerce_enabled&&item.precio_venta!=null?`<strong>${money(item.precio_venta)}</strong>`:item.precio_orientativo!=null?`<strong>${money(item.precio_orientativo)} <small>orientativo</small></strong>`:`<strong>${service?'Contactar':esc(ctaLabel(item))}</strong>`}</footer></div>
  </article>`;
}

async function buyProduct(item){
  if(isProfessionalService(item)){toast('Los servicios profesionales se contactan directamente y no utilizan el checkout de productos.','error');return;}
  if(!item?.commerce_enabled||!item?.seller_account_active){toast('Este vendedor todavía no tiene el Centro de vendedor y los cobros activos.','error');return;}
  try{if(!await ensureBuyerMarketplaceTerms())return;}catch(error){setError(error);return;}
  confirmDialog('Comprar en KOMBAX',`${item.nombre} · ${money(item.precio_venta)} · Vendido y cobrado directamente por ${item.marca_nombre}. Stripe procesa el pago para el vendedor; KOMBAX presta la plataforma y no cobra comisión por esta compraventa.`,async()=>{const out=await repos.payments.checkout('showcase_order',item.id,1);if(!out?.url)throw new Error('No se pudo abrir el pago seguro.');location.assign(out.url);},{confirmText:'Continuar al pago'});
}

async function shareItem(item){
  const text=`${item.nombre} · ${item.marca_nombre}`;
  const url=safeExternal(item.visitar_url)||location.href;
  try{
    if(navigator.share){await navigator.share({title:item.nombre,text,url});return;}
    await navigator.clipboard.writeText(`${text} ${url}`);toast('Enlace copiado');
  }catch(error){if(error?.name!=='AbortError')toast('No se pudo compartir esta ficha.','error');}
}

async function toggleSaved(item,force){
  const next=typeof force==='boolean'?force:!item.guardado;
  try{await repos.kombaxShowcase.toggleSaved(item.id,next);item.guardado=next;toast(next?'Guardado en tu Showcase':'Eliminado de guardados');if(activeView==='saved')await renderSaved();else renderCatalog();}
  catch(error){setError(error);toast(humanError(error)||'No se pudo actualizar el guardado.','error');}
}

async function openShowcaseContact(item){
  if(!item?.proveedor_social_id){toast('Este escaparate todavía no tiene un perfil KOMBAX disponible para contacto.','error');return;}
  try{
    const mine=await repos.kombaxSocial.myProfiles();
    const eligible=(Array.isArray(mine)?mine:[]).filter(x=>x.contacto_habilitado&&String(x.id)!==String(item.proveedor_social_id));
    if(!eligible.length){toast('No tienes una identidad autorizada para iniciar esta consulta de Showcase.','error');return;}
    openForm({
      title:`Consultar · ${item.nombre}`,
      subtitle:`KOMBAX Showcase · ${item.marca_nombre||'Proveedor'} · la conversación quedará vinculada a este producto o servicio.`,
      fields:[
        {name:'remitente',label:'Consultar como',type:'select',required:true,value:eligible[0].id,options:eligible.map(x=>({value:x.id,label:x.identity_label||x.nombre_publico}))},
        {name:'mensaje',label:'Primer mensaje',type:'textarea',required:true,full:true,rows:5,minLength:10,maxLength:500,help:'Entre 10 y 500 caracteres. El producto, su imagen y su referencia quedarán visibles dentro del chat.'}
      ],
      submitText:'Abrir consulta Showcase',
      onSubmit:async v=>{
        const out=await repos.kombaxSocial.showcaseContact(v.remitente,item.id,v.mensaje);
        const contactId=out?.id||out?.contacto_id||out?.contact_id||'';
        try{sessionStorage.setItem('kombax_conversation_channel','showcase');if(contactId)sessionStorage.setItem('kombax_social_open_contact',String(contactId));}catch{}
        toast('Consulta Showcase preparada en Conversaciones KOMBAX');
        setTimeout(()=>{location.hash='#conversations';},0);
      }
    });
  }catch(error){setError(error);toast(humanError(error)||'No se pudo iniciar la consulta Showcase.','error');}
}

async function runPrimaryCta(item){
  const type=item.cta_tipo||'info';
  if(type==='contact'&&item.proveedor_social_id){return openShowcaseContact(item);}
  const external=type==='where'?safeExternal(item.donde_encontrar_url):(type==='shop'||type==='web'?safeExternal(item.visitar_url):'');
  if(external){window.open(external,'_blank','noopener,noreferrer');return;}
  if(type==='contact'){
    const contact=safeExternal(item.contacto_url);if(contact){window.open(contact,'_blank','noopener,noreferrer');return;}
  }
  if(item.proveedor_social_id)return openKombaxPublicProfile(item.proveedor_social_id);
  toast('Toda la información disponible está incluida en esta ficha.');
}

function openItem(item){
  const visit=safeExternal(item.visitar_url),where=safeExternal(item.donde_encontrar_url),contact=safeExternal(item.contacto_url),image=safeExternal(item.imagen_url);
  const gallery=(Array.isArray(item.galeria)?item.galeria:[]).map(safeExternal).filter(Boolean).slice(0,3);
  const galleryHtml=gallery.length?`<div class="showcase-detail-gallery">${gallery.map((u,i)=>`<img ${mediaFrameAttrs(item?.galeria_presentacion?.[String(i)]||{},"product")} src="${esc(u)}" alt="${esc(item.nombre)}" loading="lazy">`).join('')}</div>`:'';
  const service=isProfessionalService(item);
  const commerce=!service&&item.commerce_enabled&&item.precio_venta!=null;
  const sale=`<div class="showcase-reference-price"><span>Precio</span><strong>${money(item.precio_venta)}</strong></div><div class="showcase-commerce-seller"><strong>Vendido por: ${esc(item.marca_nombre)}</strong><span>${item.fulfillment==='seller_pickup'?'Recogida gestionada por el vendedor':'Vendido y enviado por el vendedor'}</span><small>${item.stock==null?'Stock gestionado por el vendedor':`${Number(item.stock)} unidad(es) disponibles`}</small></div>`;
  const {wrap}=openDetail({title:item.nombre,subtitle:`${item.marca_nombre} · ${item.categoria_nombre||'Showcase'}`,className:'showcase-detail',body:`<div class="showcase-detail-grid"><div><div class="showcase-detail-media">${image?`<img ${mediaFrameAttrs(item.imagen_presentacion,"product")} src="${esc(image)}" alt="${esc(item.nombre)}">`:`${categoryIcon(item.categoria_slug)}<span>${esc(item.categoria_nombre||'KOMBAX')}</span>`}</div>${galleryHtml}</div><div><span class="page-kicker">INFORMACIÓN</span><p>${esc(item.descripcion||item.resumen||'Sin descripción ampliada.')}</p>${commerce?sale:item.precio_orientativo!=null?`<div class="showcase-reference-price"><span>Precio orientativo</span><strong>${money(item.precio_orientativo)}</strong></div>`:''}<div class="showcase-no-commerce">${commerce?'KOMBAX proporciona la infraestructura tecnológica. El vendedor gestiona producto, preparación, entrega y devoluciones.':service?'Servicio profesional publicado para información y contacto. No se procesa como venta de producto ni exige checkout de KOMBAX.':'La contratación, cuando exista, se realiza directamente con el perfil o su web externa.'}</div></div></div>`,actions:`${commerce?`<button class="btn btn-primary" id="showcase-buy" ${item.seller_account_active?'':'disabled'}>COMPRAR</button>`:`<button class="btn btn-primary" id="showcase-primary-cta">${esc(service?'Contactar':ctaLabel(item))}</button>`}${item.proveedor_social_id&&item.cta_tipo!=='contact'?`<button class="btn btn-showcase" id="showcase-chat-cta">${icon('message',{size:15})} Me interesa</button>`:''}<button class="btn btn-ghost" id="showcase-detail-save">${item.guardado?'Quitar de guardados':'Guardar'}</button><button class="btn btn-ghost" id="showcase-detail-share">Compartir</button>${item.proveedor_social_id?'<button class="btn btn-ghost" id="showcase-provider-profile">Ver perfil</button>':''}${visit&&item.cta_tipo!=='shop'&&item.cta_tipo!=='web'?`<a class="btn btn-ghost" href="${esc(visit)}" target="_blank" rel="noopener noreferrer">Web</a>`:''}${where&&item.cta_tipo!=='where'?`<a class="btn btn-ghost" href="${esc(where)}" target="_blank" rel="noopener noreferrer">Dónde encontrar</a>`:''}${contact&&item.cta_tipo!=='contact'&&!item.proveedor_social_id?`<a class="btn btn-ghost" href="${esc(contact)}" target="_blank" rel="noopener noreferrer">Contacto</a>`:''}`,width:'900px'});
  wrap.querySelector('#showcase-buy')?.addEventListener('click',()=>buyProduct(item));
  wrap.querySelector('#showcase-primary-cta')?.addEventListener('click',()=>runPrimaryCta(item));
  wrap.querySelector('#showcase-chat-cta')?.addEventListener('click',()=>openShowcaseContact(item));
  wrap.querySelector('#showcase-detail-save')?.addEventListener('click',async e=>{const button=e.currentTarget;if(button.dataset.kxBusy==='1')return;button.dataset.kxBusy='1';button.disabled=true;try{await toggleSaved(item);if(button.isConnected)button.textContent=item.guardado?'Quitar de guardados':'Guardar';}finally{if(button.isConnected){button.disabled=false;delete button.dataset.kxBusy;}}});
  wrap.querySelector('#showcase-detail-share')?.addEventListener('click',()=>shareItem(item));
  wrap.querySelector('#showcase-provider-profile')?.addEventListener('click',()=>openKombaxPublicProfile(item.proveedor_social_id));
}

function clubFoundersPromo(){
  return `<section class="kx-founders-promo club" aria-label="Promoción de lanzamiento para clubes"><div class="kx-founders-promo-mark">${icon('dojo',{size:28})}</div><div><span>KOMBAX SHOWCASE · LANZAMIENTO</span><strong>PRIMEROS 20 · CLUBES FUNDADORES</strong><p>Los primeros 20 clubes que completen la verificación KOMBAX quedarán incluidos en una <b>ventaja especial de lanzamiento</b> cuando KOMBAX active su modalidad de suscripción. Próximamente comunicaremos en qué consiste.</p><small>La plaza se determina por el orden de verificación KOMBAX.</small></div></section>`;
}

function bindCatalog(){
  document.getElementById('showcase-search')?.addEventListener('click',()=>{currentQuery=document.getElementById('showcase-query')?.value||'';loadCatalog(false);});
  document.getElementById('showcase-query')?.addEventListener('keydown',e=>{if(e.key==='Enter'){currentQuery=e.currentTarget.value;loadCatalog(false);}});
  document.querySelectorAll('[data-showcase-category]').forEach(b=>b.addEventListener('click',()=>{currentCategory=b.dataset.showcaseCategory||'';loadCatalog(false);}));
  document.querySelectorAll('[data-showcase-detail]').forEach(card=>{const open=()=>{const item=items.find(x=>String(x.id)===String(card.dataset.showcaseDetail));if(item)openItem(item);};card.addEventListener('click',open);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open();}});});
  document.querySelectorAll('[data-showcase-save]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const item=items.find(x=>String(x.id)===String(b.dataset.showcaseSave));if(item)toggleSaved(item);}));
  document.getElementById('showcase-more')?.addEventListener('click',()=>loadCatalog(true));
  document.getElementById('showcase-manage')?.addEventListener('click',()=>{activeView='manage';renderManagement();});
  document.getElementById('showcase-saved')?.addEventListener('click',()=>{activeView='saved';renderSaved();});
  document.getElementById('showcase-orders')?.addEventListener('click',()=>{activeView='orders';renderOrders();});
}

function renderCatalog(){
  const headActions=`<div class="row-actions">${managedBrands.length?'<button type="button" class="btn btn-ghost" id="showcase-manage">Gestionar escaparate</button>':''}<button type="button" class="btn btn-ghost" id="showcase-orders">Mis pedidos</button><button type="button" class="btn btn-ghost" id="showcase-saved">${icon('bookmark',{size:17})} Guardados</button></div>`;
  setMainHtml(`<div class="kombax-showcase-page">${showcaseBrand()}${pageHeader('Perfiles y novedades','Descubre productos, servicios y proyectos de marcas, clubes, federaciones y competidores.',headActions,'KOMBAX Showcase')}${clubFoundersPromo()}${controls()}${items.length?`<div class="showcase-grid">${items.map(cardHtml).join('')}</div>${done?'':'<button class="btn btn-ghost showcase-more" id="showcase-more">Cargar más</button>'}`:empty('Sin contenido publicado','Las fichas activas aparecerán aquí cuando sus responsables las publiquen.')}</div>`);bindCatalog();
}

async function loadCatalog(append=false){
  if(!append){cursor=null;done=false;items=[];setMainHtml('<div class="loading-card">Cargando KOMBAX Showcase…</div>');}
  try{
    const rows=await repos.kombaxShowcase.list(currentQuery,currentCategory,cursor,PAGE_SIZE);
    items=append?[...items,...rows]:rows;const last=rows.at(-1);if(last)cursor={created:last.publicado_en,id:last.id};done=rows.length<PAGE_SIZE;renderCatalog();
  }catch(error){setError(error);setMainHtml(`${showcaseBrand()}${empty('Showcase no disponible',humanError(error)||'No se ha podido cargar el escaparate. Inténtalo de nuevo.')}`);}
}

async function renderSaved(){
  setMainHtml(`<div class="kombax-showcase-page">${showcaseBrand()}${pageHeader('Guardados','Tus fichas guardadas para consultarlas más tarde.',subviewActions({backId:'showcase-back-catalog',closeId:'showcase-close-catalog',backLabel:'Volver al escaparate'}),'KOMBAX Showcase')}<div id="showcase-saved-list"><div class="loading-card">Cargando guardados…</div></div></div>`);
  bindSubviewActions(document,{backId:'showcase-back-catalog',closeId:'showcase-close-catalog',onBack:()=>{activeView='catalog';loadCatalog(false);},onClose:()=>{activeView='catalog';loadCatalog(false);}});
  const box=document.getElementById('showcase-saved-list');
  try{
    const rows=await repos.kombaxShowcase.saved(100);
    box.innerHTML=rows.length?`<div class="showcase-saved-list">${rows.map(x=>`<article><div>${x.imagen_url?`<img ${mediaFrameAttrs(x.imagen_presentacion,"product")} src="${esc(safeExternal(x.imagen_url))}" alt="">`:icon('bookmark',{size:24})}</div><section><span class="page-kicker">${esc(x.marca_nombre)}</span><strong>${esc(x.nombre)}</strong><p>${esc(x.resumen||'')}</p><small>Guardado ${dtFmt(x.guardado_en)}</small></section><button class="btn btn-ghost btn-sm" data-saved-remove="${esc(x.id)}">Quitar</button></article>`).join('')}</div>`:empty('Sin guardados','Guarda una ficha para encontrarla rápidamente aquí.');
    box.querySelectorAll('[data-saved-remove]').forEach(b=>b.addEventListener('click',async()=>{await repos.kombaxShowcase.toggleSaved(b.dataset.savedRemove,false);toast('Eliminado de guardados');await renderSaved();}));
  }catch(error){box.innerHTML=empty('No se pudieron cargar tus guardados',humanError(error)||'Inténtalo de nuevo.');}
}

async function renderOrders(){
  setMainHtml(`<div class="kombax-showcase-page">${showcaseBrand()}${pageHeader('Mis pedidos','Tus compras de KOMBAX Showcase en un único espacio: pago, preparación, envío, entrega e incidencias. El vendedor actualiza la preparación, el envío y la entrega.',subviewActions({backId:'showcase-orders-back',closeId:'showcase-orders-close',backLabel:'Volver al escaparate'}),'KOMBAX Showcase')}<div id="showcase-orders-list"><div class="loading-card">Cargando pedidos…</div></div></div>`);
  bindSubviewActions(document,{backId:'showcase-orders-back',closeId:'showcase-orders-close',onBack:()=>{activeView='catalog';loadCatalog(false);},onClose:()=>{activeView='catalog';loadCatalog(false);}});
  const box=document.getElementById('showcase-orders-list');
  try{
    const [rows,trust]=await Promise.all([repos.payments.myOrders(),repos.marketplace.buyerTrust().catch(()=>null)]);let current='all';
    const paint=()=>{const filtered=current==='all'?rows:rows.filter(o=>String(o.status)===current);const counts=Object.fromEntries(Object.keys(ORDER_STATUS).map(k=>[k,rows.filter(o=>o.status===k).length]));box.innerHTML=`${trust?buyerTrustHtml(trust):''}<div class="alert kx-market-order-responsibility"><strong>Seguimiento gestionado por el vendedor</strong><span>Después del pago, el vendedor es responsable de actualizar preparación, envío, seguimiento y entrega. Cada cambio queda registrado en el historial del pedido.</span></div><div class="showcase-order-toolbar"><button type="button" class="${current==='all'?'active':''}" data-order-filter="all">Todos <b>${rows.length}</b></button><button type="button" class="${current==='payment_confirmed'?'active':''}" data-order-filter="payment_confirmed">Pagados <b>${counts.payment_confirmed||0}</b></button><button type="button" class="${current==='preparing'?'active':''}" data-order-filter="preparing">Preparando <b>${counts.preparing||0}</b></button><button type="button" class="${current==='shipped'?'active':''}" data-order-filter="shipped">Enviados <b>${counts.shipped||0}</b></button><button type="button" class="${current==='delivered'?'active':''}" data-order-filter="delivered">Entregados <b>${counts.delivered||0}</b></button></div>${filtered.length?`<div class="showcase-order-portal">${filtered.map(o=>{const meta=orderMeta(o.status);return `<article class="showcase-order-card is-${esc(meta.tone)}"><header><div><span class="page-kicker">${esc(o.order_number)}</span><strong>${esc(orderItemsLabel(o))}</strong><small>Vendido por ${esc(o.seller||'KOMBAX Showcase')} · ${dtFmt(o.created_at)}</small></div><div class="showcase-order-total"><b>${money(o.amount_total)}</b><span>${esc(meta.label)}</span></div></header>${orderProgress(o.status)}${o.status_source==='seller'&&o.status_updated_at?`<div class="kx-order-last-update">Actualizado por el vendedor · ${dtFmt(o.status_updated_at)}</div>`:''}${o.tracking_number?`<div class="showcase-order-shipping"><strong>${icon('package',{size:15})} Seguimiento del envío</strong><span>${esc(o.carrier||'Transportista')} · ${esc(o.tracking_number)}</span>${safeExternal(o.tracking_url)?`<a href="${esc(o.tracking_url)}" target="_blank" rel="noopener noreferrer">Seguir envío</a>`:''}</div>`:''}<details><summary>Historial del pedido</summary><div class="showcase-order-history">${(o.history||[]).map(h=>`<span><i></i><b>${esc(orderMeta(h.to_status).label)}</b><small>${dtFmt(h.created_at)}</small></span>`).join('')||'<small>Sin movimientos adicionales.</small>'}</div></details>${!['cancelled','refunded'].includes(o.status)?`<footer><button class="btn btn-ghost btn-sm" data-order-incident="${esc(o.id)}">Tengo un problema</button></footer>`:''}</article>`;}).join('')}</div>`:empty('Sin pedidos en este estado',rows.length?'Cambia el filtro para consultar el resto de compras.':'Tus compras aparecerán aquí.')}`;box.querySelectorAll('[data-order-filter]').forEach(b=>b.addEventListener('click',()=>{current=b.dataset.orderFilter;paint();}));box.querySelectorAll('[data-order-incident]').forEach(b=>b.addEventListener('click',()=>openForm({title:'Tengo un problema con mi pedido',subtitle:'La incidencia queda vinculada al pedido y al vendedor.',fields:[{name:'message',label:'Describe el problema',type:'textarea',required:true,full:true,minLength:3,maxLength:4000}],submitText:'Abrir incidencia',onSubmit:async v=>{await repos.payments.orderMutate('showcase.incident.open',{order_id:b.dataset.orderIncident,message:v.message});toast('Incidencia abierta');await renderOrders();}})));box.querySelector('#buyer-identity-verify')?.addEventListener('click',()=>openBuyerIdentityVerification(renderOrders));};paint();
  }catch(error){box.innerHTML=empty('No se pudieron cargar los pedidos',humanError(error));}
}

function itemEditor(brand,item=null){
  const gallery=Array.isArray(item?.galeria)?item.galeria:[];
  const professional=isProfessionalProvider(brand),initialKind=professional?'professional_service':(item?.listing_kind||'product');
  const commonFields=[
    {name:'nombre',label:initialKind==='professional_service'?'Nombre del servicio':'Nombre',required:true,full:true},
    {name:'slug',label:'Identificador',required:true,value:item?.slug||'',help:'Minúsculas, números y guiones.'},
    {name:'listing_kind',label:'Tipo de ficha',type:'select',value:initialKind,options:professional?[{value:'professional_service',label:'Servicio profesional · contacto'}]:[{value:'product',label:'Producto · marketplace'},{value:'professional_service',label:'Servicio profesional · contacto'}],help:professional?'Los perfiles profesionales publican servicios sin checkout de producto.':'Los productos pueden activar compra directa; los servicios se publican para contacto.'},
    {name:'categoria_id',label:'Categoría',type:'select',options:categories.map(c=>({value:c.id,label:c.nombre})),value:item?.categoria_id||''},
    {name:'product_type',label:initialKind==='professional_service'?'Tipo de servicio':'Tipo de producto',value:item?.product_type||'',maxLength:80,help:'Clasificación interna para catálogo y estadísticas.'},
    {name:'resumen',label:'Resumen',type:'textarea',rows:3,maxLength:320,full:true},
    {name:'descripcion',label:'Descripción completa',type:'textarea',rows:6,maxLength:3000,full:true},
    {name:'imagen_archivo',label:'Subir imagen principal',type:'file',accept:'image/jpeg,image/png,image/webp',full:true,help:'JPG, PNG o WEBP. KOMBAX optimiza la imagen antes de publicarla.'},
    {name:'imagen_url',label:'O usar imagen principal HTTPS',type:'url',full:true},
    {name:'quitar_imagen',label:'Eliminar imagen principal actual',type:'checkbox',value:false,full:true,help:'Si eliminas o sustituyes una imagen subida a KOMBAX, su archivo anterior también se limpia del almacenamiento.'},
    {name:'galeria_archivo_1',label:'Subir imagen adicional 1',type:'file',accept:'image/jpeg,image/png,image/webp'},
    {name:'galeria_1',label:'O URL adicional 1 HTTPS',type:'url',value:gallery[0]||''},
    {name:'galeria_archivo_2',label:'Subir imagen adicional 2',type:'file',accept:'image/jpeg,image/png,image/webp'},
    {name:'galeria_2',label:'O URL adicional 2 HTTPS',type:'url',value:gallery[1]||''},
    {name:'galeria_archivo_3',label:'Subir imagen adicional 3',type:'file',accept:'image/jpeg,image/png,image/webp'},
    {name:'galeria_3',label:'O URL adicional 3 HTTPS',type:'url',value:gallery[2]||''},
    {name:'precio_orientativo',label:'Precio orientativo opcional',type:'number',min:0,step:'0.01'},
  ];
  const productFields=professional?[]:[
    {name:'sku',label:'SKU / referencia',value:item?.sku||'',maxLength:80,help:'Opcional. Ayuda a clasificar y controlar inventario.'},
    {name:'stock_alert_threshold',label:'Avisar de stock bajo a partir de',type:'number',min:0,step:'1',value:item?.stock_alert_threshold??3},
    {name:'commerce_enabled',label:'Activar venta directa en KOMBAX',type:'checkbox',value:item?.commerce_enabled===true,full:true,help:'Solo para productos. Requiere Centro de vendedor completo: identidad KOMBAX, alta de vendedor, políticas y Stripe Connect activo.'},
    {name:'precio_venta',label:'Precio de venta',type:'number',min:0,step:'0.01',value:item?.precio_venta??''},
    {name:'stock',label:'Stock disponible',type:'number',min:0,step:'1',value:item?.stock??''},
    {name:'fulfillment',label:'Entrega',type:'select',value:item?.fulfillment||'seller_shipping',options:[{value:'seller_shipping',label:'Envío por el vendedor'},{value:'seller_pickup',label:'Recogida'},{value:'seller_shipping_or_pickup',label:'Envío o recogida'},{value:'digital',label:'Entrega digital'}]},
    {name:'shipping_policy',label:'Política de envío o recogida',type:'textarea',full:true,maxLength:2000},
    {name:'returns_policy',label:'Política de devolución',type:'textarea',full:true,maxLength:2000}
  ];
  const tailFields=[
    {name:'cta_tipo',label:'Acción principal',type:'select',value:professional?'contact':(item?.cta_tipo||'info'),options:professional?[{value:'contact',label:'Contactar'}]:Object.entries(CTA_LABELS).map(([value,label])=>({value,label}))},
    {name:'cta_label',label:'Texto personalizado de la acción',maxLength:80,value:item?.cta_label||'',help:'Opcional. Si queda vacío se usa el texto estándar.'},
    {name:'visitar_url',label:'Tienda o web (HTTPS)',type:'url',full:true},
    {name:'donde_encontrar_url',label:'Dónde encontrar (HTTPS)',type:'url',full:true},
    {name:'contacto_url',label:'Contacto externo (HTTPS)',type:'url',full:true}
  ];
  openForm({
    title:item?'Editar ficha de Showcase':'Nueva ficha de Showcase',
    subtitle:`${brand.nombre} · ${PROVIDER_LABELS[brand.sujeto_tipo]||'Perfil'} · ${professional?'servicios profesionales sin checkout':LIMIT_LABELS[Number(brand.limite_visible||30)]||`máximo ${Number(brand.limite_visible||30)}`} `,
    width:'860px',initial:{...(item||{}),listing_kind:initialKind,quitar_imagen:false},fields:[...commonFields,...productFields,...tailFields],submitText:'Guardar borrador',
    onSubmit:async v=>{
      const uploaded=[],oldUrls=[item?.imagen_url,...gallery].filter(Boolean);
      try{
        const service=professional||String(v.listing_kind)==='professional_service';
        let imagen=v.quitar_imagen?'':String(v.imagen_url??item?.imagen_url??'').trim();
        if(v.imagen_archivo){const out=await repos.kombaxShowcase.uploadImage(brand.id,v.imagen_archivo);uploaded.push(out.path);imagen=out.url;}
        if(imagen&&!safeExternal(imagen))throw new Error('La imagen principal debe ser una subida válida o una URL HTTPS.');
        const galeria=[];
        for(let i=1;i<=3;i++){
          const file=v[`galeria_archivo_${i}`];let url=String(v[`galeria_${i}`]??gallery[i-1]??'').trim();
          if(file){const out=await repos.kombaxShowcase.uploadImage(brand.id,file);uploaded.push(out.path);url=out.url;}
          if(url){if(!safeExternal(url))throw new Error(`La imagen adicional ${i} debe usar una URL HTTPS válida.`);galeria.push(url);}
        }
        const ctaTipo=service?'contact':v.cta_tipo;
        const required=ctaTipo==='where'?v.donde_encontrar_url:(ctaTipo==='shop'||ctaTipo==='web'?v.visitar_url:'');
        if(required&&!safeExternal(required))throw new Error('La acción principal seleccionada necesita una URL HTTPS válida.');
        const saved=await repos.kombaxShowcase.saveItem({...v,id:item?.id||null,marca_id:brand.id,slug:v.slug||slugify(v.nombre),imagen_url:imagen,galeria,moneda:'EUR',cta_tipo:ctaTipo});
        const savedId=saved?.id||item?.id;
        if(savedId){
          await repos.kombaxShowcase.saveListingMeta(savedId,{listing_kind:service?'professional_service':'product',product_type:v.product_type||null,sku:service?null:(v.sku||null),stock_alert_threshold:service?0:Number(v.stock_alert_threshold??3)});
          await repos.kombaxShowcase.saveCommerce(savedId,{commerce_enabled:service?false:v.commerce_enabled===true,precio_venta:service?null:(v.precio_venta===''?null:Number(v.precio_venta)),stock:service?null:(v.stock===''?null:Number(v.stock)),variantes:service?[]:(item?.variantes||[]),fulfillment:service?'digital':v.fulfillment,shipping_policy:service?null:(v.shipping_policy||null),returns_policy:service?null:(v.returns_policy||null)});
        }
        const retained=new Set([imagen,...galeria].filter(Boolean));
        await repos.kombaxShowcase.removeOwnedImages(oldUrls.filter(u=>!retained.has(u))).catch(()=>{});
        toast(service?'Servicio guardado. Se publicará como ficha de contacto, sin checkout.':'Producto guardado. Pulsa Publicar para hacerlo visible en Marketplace.');await renderManagement(brand.id);
      }catch(error){for(const path of uploaded)await repos.kombaxShowcase.removeUploadedImage(path).catch(()=>{});throw error;}
    }
  });
}

async function openSellerOrders(brand){
  try{
    const rows=await repos.payments.sellerOrders(brand.id);let current='open';let modal;
    const group=o=>['delivered','cancelled','refunded'].includes(o.status)?'closed':o.status==='incident'?'incident':'open';
    const body=()=>{const filtered=current==='all'?rows:current==='open'?rows.filter(o=>group(o)==='open'):current==='incident'?rows.filter(o=>o.status==='incident'):rows.filter(o=>o.status===current);const count=k=>k==='open'?rows.filter(o=>group(o)==='open').length:k==='all'?rows.length:rows.filter(o=>o.status===k).length;return `<div class="showcase-seller-orders"><div class="alert kx-market-order-responsibility"><strong>Responsabilidad del vendedor</strong><span>Debes mantener actualizado cada pedido: iniciar preparación, informar el envío y confirmar la entrega/recogida. El comprador ve estos cambios en Mis pedidos.</span></div><div class="showcase-order-toolbar"><button data-seller-filter="open" class="${current==='open'?'active':''}">Pendientes <b>${count('open')}</b></button><button data-seller-filter="payment_confirmed" class="${current==='payment_confirmed'?'active':''}">Pagados <b>${count('payment_confirmed')}</b></button><button data-seller-filter="preparing" class="${current==='preparing'?'active':''}">Preparando <b>${count('preparing')}</b></button><button data-seller-filter="shipped" class="${current==='shipped'?'active':''}">Enviados <b>${count('shipped')}</b></button><button data-seller-filter="incident" class="${current==='incident'?'active':''}">Incidencias <b>${count('incident')}</b></button><button data-seller-filter="all" class="${current==='all'?'active':''}">Todos <b>${rows.length}</b></button></div>${filtered.length?`<div class="showcase-order-portal seller">${filtered.map(o=>{const meta=orderMeta(o.status),address=shippingLine(o);return `<article class="showcase-order-card is-${esc(meta.tone)}"><header><div><span class="page-kicker">${esc(o.order_number)}</span><strong>${esc(orderItemsLabel(o))}</strong><small>${esc(o.buyer_email||'Comprador KOMBAX')} · ${dtFmt(o.created_at)}</small></div><div class="showcase-order-total"><b>${money(o.amount_total)}</b><span>${esc(meta.label)}</span></div></header>${orderProgress(o.status)}${(o.shipping_name||address)?`<div class="showcase-order-address"><strong>${icon('mapPin',{size:15})} Entrega</strong><span>${esc(o.shipping_name||'Destinatario')}${o.shipping_phone?` · ${esc(o.shipping_phone)}`:''}</span>${address?`<small>${esc(address)}</small>`:''}</div>`:''}${o.status_source==='seller'&&o.status_updated_at?`<div class="kx-order-last-update">Actualizado por el vendedor · ${dtFmt(o.status_updated_at)}</div>`:''}${o.tracking_number?`<div class="showcase-order-shipping"><strong>Seguimiento</strong><span>${esc(o.carrier||'Transportista')} · ${esc(o.tracking_number)}</span>${safeExternal(o.tracking_url)?`<a href="${esc(o.tracking_url)}" target="_blank" rel="noopener noreferrer">Abrir seguimiento</a>`:''}</div>`:''}<details><summary>Historial</summary><div class="showcase-order-history">${(o.history||[]).map(h=>`<span><i></i><b>${esc(orderMeta(h.to_status).label)}</b><small>${dtFmt(h.created_at)}</small></span>`).join('')}</div></details><footer class="row-actions">${o.status==='payment_confirmed'?`<button class="btn btn-primary btn-sm" data-order-status="preparing" data-order-id="${esc(o.id)}">Empezar preparación</button>`:''}${o.status==='preparing'?`<button class="btn btn-primary btn-sm" data-order-ship="${esc(o.id)}">Marcar enviado</button><button class="btn btn-ghost btn-sm" data-order-status="delivered" data-order-id="${esc(o.id)}">Entregado / recogido</button>`:''}${o.status==='shipped'?`<button class="btn btn-primary btn-sm" data-order-status="delivered" data-order-id="${esc(o.id)}">Confirmar entrega</button>`:''}</footer></article>`;}).join('')}</div>`:empty('Sin pedidos en este estado','Los nuevos pedidos aparecerán aquí tras confirmarse el pago.')}</div>`;};
    const bindModal=()=>{modal.wrap.querySelectorAll('[data-seller-filter]').forEach(b=>b.addEventListener('click',()=>{current=b.dataset.sellerFilter;modal.wrap.querySelector('.detail-modal-body').innerHTML=body();bindModal();}));modal.wrap.querySelectorAll('[data-order-status]').forEach(b=>b.addEventListener('click',async()=>{b.disabled=true;try{await repos.payments.orderMutate('showcase.order.status',{order_id:b.dataset.orderId,status:b.dataset.orderStatus});toast('Pedido actualizado');modal.close();await openSellerOrders(brand);}catch(error){b.disabled=false;setError(error);}}));modal.wrap.querySelectorAll('[data-order-ship]').forEach(b=>b.addEventListener('click',()=>openForm({title:'Marcar pedido como enviado',subtitle:'El comprador verá estos datos en Mis pedidos.',fields:[{name:'carrier',label:'Transportista',required:true},{name:'tracking_number',label:'Número de seguimiento',required:true},{name:'tracking_url',label:'URL de seguimiento',type:'url'}],submitText:'Guardar envío',onSubmit:async v=>{await repos.payments.orderMutate('showcase.order.status',{order_id:b.dataset.orderShip,status:'shipped',...v});toast('Envío guardado');modal.close();await openSellerOrders(brand);}})));};
    modal=openDetail({title:'Pedidos del vendedor',subtitle:`${brand.nombre} · preparación, envío y entrega`,width:'1040px',className:'showcase-seller-order-modal',body:body()});bindModal();
  }catch(error){setError(error);}
}

async function openSellerDashboard(brand){
  try{
    const data=await repos.kombaxShowcase.sellerDashboard(brand.id),stats=data?.stats||{},inventory=Array.isArray(data?.inventory)?data.inventory:[],top=Array.isArray(data?.top_products)?data.top_products:[],byType=Array.isArray(data?.by_type)?data.by_type:[];
    const kpi=(label,value,help='')=>`<article><small>${esc(label)}</small><strong>${esc(String(value??0))}</strong>${help?`<span>${esc(help)}</span>`:''}</article>`;
    openDetail({title:'Showcase · Inventario y estadísticas',subtitle:`${brand.nombre} · ${PROVIDER_LABELS[brand.sujeto_tipo]||'Proveedor'}`,width:'1100px',className:'kx-seller-dashboard-modal',body:`<div class="kx-seller-dashboard-grid">${kpi('Productos',stats.products||0)}${kpi('Servicios',stats.services||0)}${kpi('Stock total',stats.stock_units||0)}${kpi('Stock bajo',stats.low_stock||0)}${kpi('Sin stock',stats.out_of_stock||0)}${kpi('Productos vendidos',stats.sold_products||0)}${kpi('Sin ventas',stats.unsold_products||0)}${kpi('Unidades vendidas',stats.units_sold||0)}${kpi('Pedidos',stats.orders||0)}${kpi('GMV producto',money((Number(stats.product_gmv_minor)||0)/100),'Volumen bruto vendido; no es ingreso KOMBAX.')}</div>
      <section class="kx-seller-dashboard-section"><h4>Inventario y catálogo</h4>${inventory.length?`<div class="kx-seller-inventory">${inventory.map(row=>`<article><div><span class="page-kicker">${row.listing_kind==='professional_service'?'SERVICIO':'PRODUCTO'}${row.product_type?` · ${esc(row.product_type)}`:''}</span><strong>${esc(row.name)}</strong><small>${row.sku?`SKU ${esc(row.sku)} · `:''}${row.listing_kind==='professional_service'?'Sin stock/checkout':`${stockStatusLabel(row.stock_status)} · ${row.stock==null?'sin control':`${Number(row.stock)} uds.`}`} · ${row.sold?'Vendido':'Sin ventas'}</small></div><div><b>${Number(row.units_sold||0)} uds.</b><small>${Number(row.orders||0)} pedidos · ${money((Number(row.gmv_minor)||0)/100)}</small></div></article>`).join('')}</div>`:empty('Sin fichas','Crea productos o servicios para empezar a medir el catálogo.')}</section>
      <section class="kx-seller-dashboard-section"><h4>Clasificación</h4><div class="kx-seller-type-chips">${byType.length?byType.map(x=>`<span>${esc(x.type)} <b>${Number(x.count||0)}</b></span>`).join(''):'<span>Sin productos clasificados</span>'}</div></section>
      <section class="kx-seller-dashboard-section"><h4>Productos más vendidos</h4>${top.length?`<div class="kx-seller-top">${top.map((x,i)=>`<article><b>#${i+1}</b><div><strong>${esc(x.name)}</strong><small>${Number(x.units_sold||0)} unidades · ${Number(x.orders||0)} pedidos · ${money((Number(x.gmv_minor)||0)/100)}</small></div></article>`).join('')}</div>`:'<p class="muted">Todavía no hay ventas confirmadas.</p>'}</section>`});
  }catch(error){setError(error);toast(humanError(error)||'No se pudieron cargar las estadísticas.','error');}
}

async function renderManagement(selectedBrandId=''){
  const brand=managedBrands.find(x=>x.id===selectedBrandId)||managedBrands[0];
  if(!brand){activeView='catalog';return loadCatalog(false);}
  const professional=isProfessionalProvider(brand);
  const [sellerCenter,dashboard]=await Promise.all([
    professional?Promise.resolve(null):repos.marketplace.sellerCenter(brand.id).catch(()=>null),
    repos.kombaxShowcase.sellerDashboard(brand.id).catch(()=>null)
  ]);
  const sellerReady=sellerCenter?.checks?.selling_ready===true,stats=dashboard?.stats||{};
  const commercialActions=professional
    ?`<span class="kx-market-status ok">${icon('checkCircle',{size:14})} Servicios profesionales · sin checkout</span>`
    :`<button class="btn ${sellerReady?'btn-ghost':'btn-primary'}" id="showcase-seller-center">${sellerReady?'✓ Vendedor activo':'Centro de vendedor'}</button><button class="btn btn-ghost" id="showcase-seller-orders">Pedidos</button>`;
  const dashboardStrip=`<div class="kx-showcase-management-kpis"><article><small>Productos</small><strong>${Number(stats.products||0)}</strong></article><article><small>Servicios</small><strong>${Number(stats.services||0)}</strong></article><article><small>Stock</small><strong>${Number(stats.stock_units||0)}</strong></article><article><small>Stock bajo / agotado</small><strong>${Number(stats.low_stock||0)+Number(stats.out_of_stock||0)}</strong></article><article><small>Vendidos / no vendidos</small><strong>${Number(stats.sold_products||0)} / ${Number(stats.unsold_products||0)}</strong></article><article><small>Unidades vendidas</small><strong>${Number(stats.units_sold||0)}</strong></article><article><small>Pedidos</small><strong>${Number(stats.orders||0)}</strong></article></div>`;
  setMainHtml(`<div class="kombax-showcase-page">${showcaseBrand()}${pageHeader('Gestión de Showcase',professional?'Publica y clasifica tus servicios profesionales para que otros usuarios puedan encontrarte y contactarte. No necesitas activar venta de productos ni Stripe.':'Gestiona tu marketplace: catálogo, stock, vendedor, pedidos, envíos y estadísticas.',subviewActions({backId:'showcase-back',closeId:'showcase-close',backLabel:'Volver a Showcase'}),'KOMBAX Showcase')}<div class="showcase-management-head"><label>Espacio gestionado<select id="showcase-brand-select">${managedBrands.map(x=>`<option value="${esc(x.id)}" ${x.id===brand.id?'selected':''}>${esc(x.nombre)} · ${esc(PROVIDER_LABELS[x.sujeto_tipo]||'Perfil')}</option>`).join('')}</select></label><div class="showcase-provider-limit"><strong>${Number(brand.publicados||0)}/${Number(brand.limite_visible||30)}</strong><span>fichas visibles</span></div>${commercialActions}<button class="btn btn-ghost" id="showcase-seller-dashboard">Inventario y estadísticas</button><button class="btn btn-primary" id="showcase-new-item">+ ${professional?'Nuevo servicio':'Nueva ficha'}</button></div>${professional?`<div class="alert success"><strong>Showcase de servicios profesionales</strong><span>Este perfil puede publicar servicios y recibir contactos sin alta como vendedor, sin stock y sin checkout. Si en el futuro vende productos físicos, esa función deberá pasar por Marketplace + Seller Center.</span></div>`:sellerCenter&&!sellerReady?`<div class="alert"><strong>Venta directa pendiente de activación</strong><span>Completa identidad, alta de vendedor, políticas y Stripe Connect. Puedes preparar productos como borrador mientras tanto.</span></div>`:''}${dashboardStrip}<div id="showcase-managed-items"><div class="loading-card">Cargando fichas…</div></div></div>`);
  bindSubviewActions(document,{backId:'showcase-back',closeId:'showcase-close',onBack:()=>{activeView='catalog';loadCatalog(false);},onClose:()=>{activeView='catalog';loadCatalog(false);}});
  document.getElementById('showcase-brand-select')?.addEventListener('change',e=>renderManagement(e.target.value));
  document.getElementById('showcase-new-item')?.addEventListener('click',()=>itemEditor(brand));
  document.getElementById('showcase-seller-center')?.addEventListener('click',()=>openSellerCenter(brand));
  document.getElementById('showcase-seller-orders')?.addEventListener('click',()=>openSellerOrders(brand));
  document.getElementById('showcase-seller-dashboard')?.addEventListener('click',()=>openSellerDashboard(brand));
  const box=document.getElementById('showcase-managed-items');
  try{
    const rows=await repos.kombaxShowcase.myItems(brand.id,managementLimit),inventoryMap=new Map((dashboard?.inventory||[]).map(x=>[String(x.id),x]));
    box.innerHTML=rows.length?`<div class="showcase-manage-list">${rows.map(x=>{const inv=inventoryMap.get(String(x.id))||x,service=isProfessionalService(x);return `<article><div><span class="page-kicker">${service?'SERVICIO PROFESIONAL':'PRODUCTO'} · ${esc(x.estado)}${x.destacado?' · destacado':''}</span><strong>${esc(x.nombre)}</strong><small>${esc(x.product_type||x.categoria_nombre||'Sin clasificar')} · ${service?'Contacto sin checkout':`${stockStatusLabel(inv.stock_status)}${x.sku?` · SKU ${esc(x.sku)}`:''} · ${inv.sold?'Vendido':'No vendido'}`} · Actualizado ${dtFmt(x.actualizado_en)}</small></div><div class="row-actions">${x.imagen_url?`<button class="btn btn-ghost btn-sm" data-showcase-frame="${esc(x.id)}">Ajustar imagen</button>`:''}${Array.isArray(x.galeria)&&x.galeria.filter(Boolean).length?`<button class="btn btn-ghost btn-sm" data-showcase-gallery-frame="${esc(x.id)}">Ajustar galería</button>`:''}<button class="btn btn-ghost btn-sm" data-showcase-edit="${esc(x.id)}">Editar</button>${x.estado!=='publicado'?`<button class="btn btn-primary btn-sm" data-showcase-state="publicado" data-showcase-id="${esc(x.id)}">Publicar</button>`:`<button class="btn btn-ghost btn-sm" data-showcase-state="archivado" data-showcase-id="${esc(x.id)}">Archivar</button>`}<button class="btn btn-danger btn-sm" data-showcase-delete="${esc(x.id)}">${icon('trash',{size:14})} Eliminar</button></div></article>`;}).join('')}</div>${rows.length>=managementLimit&&managementLimit<200?'<div class="load-more-wrap"><button class="btn btn-ghost" id="load-more-showcase-management">Cargar fichas anteriores</button></div>':''}`:empty('Sin fichas',professional?'Publica tu primer servicio profesional.':'Crea el primer producto o servicio de este espacio.');
    box.querySelector('#load-more-showcase-management')?.addEventListener('click',()=>{managementLimit=Math.min(200,managementLimit+60);renderManagement(brand.id);});
    box.querySelectorAll('[data-showcase-frame]').forEach(b=>b.addEventListener('click',()=>{const row=rows.find(x=>x.id===b.dataset.showcaseFrame),src=safeExternal(row?.imagen_url);if(!row||!src)return;openMediaFramingEditor({title:`Ajustar · ${row.nombre}`,subtitle:'Conserva el original y elige el encuadre.',src,initial:row.imagen_presentacion,preset:'product',onSave:async presentation=>{await repos.mediaFraming.set('showcase_item',row.id,presentation);row.imagen_presentacion=presentation;setTimeout(()=>renderManagement(brand.id),80);}});}));
    box.querySelectorAll('[data-showcase-gallery-frame]').forEach(b=>b.addEventListener('click',()=>{const row=rows.find(x=>x.id===b.dataset.showcaseGalleryFrame),gallery=(Array.isArray(row?.galeria)?row.galeria:[]).map(safeExternal).filter(Boolean).slice(0,3);if(!row||!gallery.length)return;const modal=openDetail({title:`Ajustar galería · ${row.nombre}`,subtitle:'Cada imagen conserva su original y su encuadre propio.',body:`<div class="showcase-detail-gallery kx-showcase-gallery-editor">${gallery.map((u,i)=>`<article><img ${mediaFrameAttrs(row?.galeria_presentacion?.[String(i)]||{},'product')} src="${esc(u)}" alt="${esc(row.nombre)}"><button type="button" class="btn btn-ghost btn-sm" data-showcase-gallery-slot="${i}">Ajustar imagen ${i+1}</button></article>`).join('')}</div>`,width:'900px'});modal.wrap.querySelectorAll('[data-showcase-gallery-slot]').forEach(btn=>btn.addEventListener('click',()=>{const i=Number(btn.dataset.showcaseGallerySlot),src=gallery[i];openMediaFramingEditor({title:`Ajustar imagen ${i+1} · ${row.nombre}`,subtitle:'Puedes mostrar el producto completo o rellenar el marco.',src,initial:row?.galeria_presentacion?.[String(i)]||{},preset:'product',onSave:async presentation=>{await repos.mediaFraming.set(`showcase_gallery_${i}`,row.id,presentation);row.galeria_presentacion={...(row.galeria_presentacion||{}),[String(i)]:presentation};setTimeout(()=>renderManagement(brand.id),80);}});}));}));
    box.querySelectorAll('[data-showcase-edit]').forEach(b=>b.addEventListener('click',()=>itemEditor(brand,rows.find(x=>x.id===b.dataset.showcaseEdit))));
    box.querySelectorAll('[data-showcase-state]').forEach(b=>b.addEventListener('click',()=>confirmDialog(b.dataset.showcaseState==='publicado'?'Publicar ficha':'Archivar ficha',b.dataset.showcaseState==='publicado'?'La información será visible en Showcase.':'La ficha dejará de mostrarse sin eliminar su historial.',async()=>{await repos.kombaxShowcase.itemState(b.dataset.showcaseId,b.dataset.showcaseState);toast(b.dataset.showcaseState==='publicado'?'Ficha publicada':'Ficha archivada');await renderManagement(brand.id);},{confirmText:b.dataset.showcaseState==='publicado'?'Publicar':'Archivar'})));
    box.querySelectorAll('[data-showcase-delete]').forEach(b=>b.addEventListener('click',()=>confirmDialog('Eliminar ficha de Showcase','La ficha desaparecerá de Showcase, del perfil público y de los guardados. Las imágenes subidas por esta cuenta que ya no se usan también se eliminarán del almacenamiento.',async()=>{await repos.kombaxShowcase.deleteItem(b.dataset.showcaseDelete);toast('Ficha e imágenes propias eliminadas');await renderManagement(brand.id);},{confirmText:'Eliminar definitivamente',danger:true})));
  }catch(error){box.innerHTML=empty('No se pudo cargar la gestión',humanError(error)||'Revisa tus permisos.');}
}

export async function renderShowcase(){
  setMainHtml('<div class="loading-card">Abriendo KOMBAX Showcase…</div>');
  try{[categories,managedBrands]=await Promise.all([repos.kombaxShowcase.categories(),repos.kombaxShowcase.myBrands().catch(()=>[])]);}catch(error){setError(error);setMainHtml(empty('Showcase no disponible',humanError(error)||'No se ha podido cargar el escaparate. Inténtalo de nuevo.'));return;}
  if(activeView==='manage'&&managedBrands.length)return renderManagement();
  if(activeView==='saved')return renderSaved();
  if(activeView==='orders')return renderOrders();
  activeView='catalog';return loadCatalog(false);
}
